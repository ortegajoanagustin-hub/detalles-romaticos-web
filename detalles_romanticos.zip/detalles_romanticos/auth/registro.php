<?php
// auth/registro.php — formulario de registro de clientes
$titulo = 'Crear cuenta';
require_once __DIR__ . '/../includes/header.php';
if (usuario_actual()) redirigir('index.php');
$old = $_SESSION['old'] ?? []; unset($_SESSION['old']);
?>
<div class="auth-shell">
  <aside class="auth-visual">
    <div><a href="<?= e(url('index.php')) ?>" class="brand"><span class="mark">♥</span><span>AMOR &amp; DETALLE</span></a></div>
    <blockquote>
      “Elegí, personalizá y regalá. Un detalle con historia.”
      <cite>— AMOR &amp; DETALLE</cite>
    </blockquote>
    <a href="<?= e(url('index.php')) ?>" class="auth-back">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
      Volver a la tienda
    </a>
  </aside>

  <div class="auth-form-side">
    <div class="auth-card">
      <h1>Creá tu cuenta</h1>
      <p class="lead">Registrate para guardar tu carrito y seguir tus pedidos.</p>

      <?= flash_mostrar() ?>

      <form id="registro-form" action="procesar_registro.php" method="post" novalidate>
        <?= csrf_campo() ?>
        <div class="field">
          <label for="registro-name">Nombre completo</label>
          <div class="input-wrap">
            <input type="text" id="registro-name" name="nombre" value="<?= e($old['nombre'] ?? '') ?>" placeholder="Como querés que te llamemos" maxlength="50" required>
          </div>
          <p class="error-msg"></p>
        </div>
        <div class="field">
          <label for="registro-email">Email</label>
          <div class="input-wrap">
            <input type="email" id="registro-email" name="email" value="<?= e($old['email'] ?? '') ?>" placeholder="tu@email.com" maxlength="100" required>
          </div>
          <p class="error-msg"></p>
        </div>
        <div class="field">
          <label for="registro-password">Contraseña</label>
          <div class="input-wrap">
            <input type="password" id="registro-password" name="password" placeholder="Mínimo 6 caracteres" required>
            <button type="button" class="toggle-pass">Ver</button>
          </div>
          <p class="error-msg"></p>
        </div>
        <div class="field">
          <label for="registro-confirm">Confirmar contraseña</label>
          <div class="input-wrap">
            <input type="password" id="registro-confirm" name="confirmar" placeholder="Repetí tu contraseña" required>
            <button type="button" class="toggle-pass">Ver</button>
          </div>
          <p class="error-msg"></p>
        </div>
        <div class="checkbox-row">
          <input type="checkbox" id="registro-terms" name="terminos" value="1">
          <label for="registro-terms">Acepto los términos y condiciones y la política de privacidad.</label>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Crear cuenta</button>
      </form>

      <p class="auth-switch">¿Ya tenés cuenta? <a href="<?= e(url('auth/login.php')) ?>">Iniciá sesión</a></p>
    </div>
  </div>
</div>
<script src="<?= e(url('js/main.js') . '?v=' . @filemtime(__DIR__ . '/../js/main.js')) ?>"></script>
</body>
</html>
