<?php
// auth/procesar_registro.php — valida, guarda el usuario (rol SIEMPRE 'cliente') y crea su carrito
require_once __DIR__ . '/../includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirigir('auth/registro.php');
csrf_verificar();

$nombre    = trim($_POST['nombre'] ?? '');
$email     = strtolower(trim($_POST['email'] ?? ''));
$password  = $_POST['password'] ?? '';
$confirmar = $_POST['confirmar'] ?? '';
$terminos  = isset($_POST['terminos']);

$errores = [];
if (largo($nombre) < 2 || largo($nombre) > 50)       $errores[] = 'El nombre debe tener entre 2 y 50 caracteres.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || largo($email) > 100) $errores[] = 'Ingresá un email válido.';
if (strlen($password) < 6)                                   $errores[] = 'La contraseña debe tener al menos 6 caracteres.';
if ($password !== $confirmar)                                $errores[] = 'Las contraseñas no coinciden.';
if (!$terminos)                                              $errores[] = 'Tenés que aceptar los términos y condiciones.';

if (!$errores) {
    $st = $pdo->prepare('SELECT id FROM usuarios WHERE email = ?');
    $st->execute([$email]);
    if ($st->fetch()) $errores[] = 'Ya existe una cuenta con ese email.';
}

if ($errores) {
    foreach ($errores as $err) flash('error', $err);
    $_SESSION['old'] = ['nombre' => $nombre, 'email' => $email];
    redirigir('auth/registro.php');
}

try {
    $pdo->beginTransaction();
    $pdo->prepare("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'cliente')")
        ->execute([$nombre, $email, password_hash($password, PASSWORD_DEFAULT)]);
    $pdo->prepare('INSERT INTO carrito (usuario_id) VALUES (?)')->execute([(int)$pdo->lastInsertId()]);
    $pdo->commit();
} catch (PDOException $ex) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('Registro: ' . $ex->getMessage());
    flash('error', ($ex->getCode() === '23000') ? 'Ya existe una cuenta con ese email.' : 'No pudimos crear la cuenta. Probá de nuevo.');
    $_SESSION['old'] = ['nombre' => $nombre, 'email' => $email];
    redirigir('auth/registro.php');
}

flash('ok', '¡Cuenta creada! Ya podés iniciar sesión.');
redirigir('auth/login.php');
