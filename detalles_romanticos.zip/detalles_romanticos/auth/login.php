<?php
// auth/login.php — formulario de inicio de sesión
$titulo = 'Iniciar sesión';
require_once __DIR__ . '/../includes/header.php';
if (usuario_actual()) redirigir('index.php');
$old = $_SESSION['old'] ?? []; unset($_SESSION['old']);
?>
<div class="auth-shell">
  <aside class="auth-visual">
    <div><a href="<?= e(url('index.php')) ?>" class="brand"><span class="mark">♥</span><span>AMOR &amp; DETALLE</span></a></div>
    <blockquote>
      “Antes de agregar al carrito, ya sabía exactamente cómo iba a quedar. Eso fue lo que me convenció.”
      <cite>— Testimonio de ejemplo</cite>
    </blockquote>
    <a href="<?= e(url('index.php')) ?>" class="auth-back">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
      Volver a la tienda
    </a>
  </aside>

  <div class="auth-form-side">
    <div class="auth-card">
      <h1>Bienvenido/a de nuevo</h1>
      <p class="lead">Ingresá para ver tu carrito y tus pedidos.</p>

      <?= flash_mostrar() ?>

      <form id="login-form" action="procesar_login.php" method="post" novalidate>
        <?= csrf_campo() ?>
        <div class="field">
          <label for="login-email">Email</label>
          <div class="input-wrap">
            <input type="email" id="login-email" name="email" value="<?= e($old['email'] ?? '') ?>" placeholder="tu@email.com" maxlength="100" required>
          </div>
          <p class="error-msg"></p>
        </div>
        <div class="field">
          <label for="login-password">Contraseña</label>
          <div class="input-wrap">
            <input type="password" id="login-password" name="password" placeholder="••••••••" required>
            <button type="button" class="toggle-pass">Ver</button>
          </div>
          <p class="error-msg"></p>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Iniciar sesión</button>
      </form>

      <p class="auth-switch">¿Todavía no tenés cuenta? <a href="<?= e(url('auth/registro.php')) ?>">Creá una gratis</a></p>
    </div>
  </div>
</div>
<script src="<?= e(url('js/main.js') . '?v=' . @filemtime(__DIR__ . '/../js/main.js')) ?>"></script>
</body>
</html>
