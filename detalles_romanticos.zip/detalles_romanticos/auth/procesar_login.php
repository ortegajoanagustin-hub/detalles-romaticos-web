<?php
// auth/procesar_login.php — verifica credenciales con password_verify y abre la sesión
require_once __DIR__ . '/../includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirigir('auth/login.php');
csrf_verificar();

$email    = strtolower(trim($_POST['email'] ?? ''));
$password = $_POST['password'] ?? '';

$st = $pdo->prepare('SELECT id, nombre, email, password, rol FROM usuarios WHERE email = ?');
$st->execute([$email]);
$u = $st->fetch();

if (!$u || !password_verify($password, $u['password'])) {
    // Mensaje genérico a propósito: no revela si el email existe.
    flash('error', 'Email o contraseña incorrectos.');
    $_SESSION['old'] = ['email' => $email];
    redirigir('auth/login.php');
}

if (password_needs_rehash($u['password'], PASSWORD_DEFAULT)) {
    $pdo->prepare('UPDATE usuarios SET password = ? WHERE id = ?')
        ->execute([password_hash($password, PASSWORD_DEFAULT), $u['id']]);
}

session_regenerate_id(true);   // evita fijación de sesión
$_SESSION['usuario'] = ['id' => (int)$u['id'], 'nombre' => $u['nombre'], 'email' => $u['email'], 'rol' => $u['rol']];
carrito_id($pdo, (int)$u['id']);

redirigir($u['rol'] === 'admin' ? 'admin/dashboard.php' : 'index.php');
