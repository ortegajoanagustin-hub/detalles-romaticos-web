# Estado del avance — entrega 16/10

Enunciado: *login y registro funcionando, carga de productos con su conexión, base de datos terminada y avance de la interfaz gráfica.*

## 1. Estado de cada punto

| Punto del enunciado | Estado ANTES (lo que subiste) | Estado AHORA |
|---|---|---|
| **Login** | Solo HTML + JS que simulaba el ingreso con un `setTimeout`. `auth/login.php` y `procesar_login.php` estaban vacíos. | ✅ Funciona: `password_verify`, sesión, redirección por rol, token CSRF, mensaje genérico de error. |
| **Registro** | `auth/registro.php` sin atributos `name` en los inputs (el POST llegaba vacío), sin estilos. `procesar_registro.php` vacío. | ✅ Funciona: validación, `password_hash`, email único, crea el carrito del usuario. El rol siempre es `cliente` (probado que no se puede inyectar `admin`). |
| **Carga de productos** | `agregar_producto.php`, `guardar_ptoducto.php` (typo en el nombre) y `dashboard.php` vacíos. | ✅ Formulario + guardado con consulta preparada, subida de imagen validada por tipo real, listado y baja en el panel admin. |
| **Conexión a la BD** | `conexion.php` no corría: 5 errores de sintaxis (ver §2) y apuntaba a una BD distinta de la del DER. | ✅ Corregida y probada contra MariaDB 10.11. |
| **Base de datos terminada** | DER (`si.vuerd`) y `der.sql` coinciden entre sí y están bien, **pero la BD real de phpMyAdmin no es esa** (ver §3). | ✅ Script único `database/detalles_romanticos.sql` con el DER + mejoras + datos de prueba. Validado. |
| **Interfaz gráfica** | `index.html` (539 líneas), `login.html`, `registro.html` y CSS de 837 líneas: buen diseño, pero estático; en login/registro **ni el CSS ni el JS cargaban** (rutas rotas). | ✅ Diseño conservado y conectado: `index.php` con catálogo desde la BD, detalle de producto, carrito, panel admin. |

## 2. Errores que había y que impedían que algo funcionara
- `conexion.php`: `PDO::ERRMPDE_EXCEPTION` (es `ERRMODE_EXCEPTION`), falta `=>` en `ATTR_DEFAULT_FETCH_MODE`, `&dsn` en vez de `$dsn`, `catch{` sin `(PDOException $e)`, y espacios en el DSN (`host = $host`).
- `login.html` / `registro.html` cargaban `stylesheet.css` y `app.js`, pero los archivos están en `css/stylesheet.css` y `js/main.js`.
- `registro.php`: inputs sin `name`, `<label for>` sin `id` correspondiente, sin `<link>` al CSS, enlace a `login.php` (que estaba vacío).
- 12 archivos PHP con 0 bytes (`login`, `procesar_*`, `log_out`, `index`, `producto`, `carrito`, `dashboard`, `agregar_producto`, `includes/*`) y `readme.md` vacío.

## 3. Desajuste entre la base de datos real y el DER (lo más grave)
Según tus capturas de phpMyAdmin, la BD que tenés corriendo **no es la del DER**:

| Tema | En phpMyAdmin | En el DER / `der.sql` |
|---|---|---|
| Nombre de la BD | `detalles_romanticos` (según `conexion.php`) | `sistema` (según `der.sql`) |
| Productos | tabla `productos` **con una columna `pedido_id`** (un producto ligado a un solo pedido: error de diseño) | tabla `regalos`, sin `pedido_id` |
| Detalle de pedido | `detalle_pedidos` con `producto_id` | `detalle_pedido` con `regalo_id` |
| Usuarios | columna `mail` (50) | columna `email` (100) |
| `pedidos.total` | `decimal(10,0)` (pierde los centavos) | `decimal(10,2)` |
| `pedidos.estado` | enum con textos como `'el producto va a saer enviado'` y `'¡producto recibido!'` (typo y signos) | `pendiente, pagado, enviado, recibido, cancelado` |
| Carrito | no existen `carrito` ni `detalle_carrito` | existen |
| `productos.imagen` | NOT NULL | permite NULL |

**Qué hacer:** ejecutar `database/detalles_romanticos.sql`. Elimina las tablas viejas y crea las del DER. Si tenés datos que quieras conservar en la BD vieja, exportalos antes.

## 4. Cambios que sugerí en el modelo (ya aplicados en el SQL)
Si los aceptás, actualizá también `si.vuerd` y la carpeta del sistema.
1. `regalos.categoria` (nuevo): el catálogo ya filtra por Joyería / Flores / Gourmet / Cajas / Experiencias y el DER no tenía dónde guardarlo.
2. `carrito.usuario_id` UNIQUE: un carrito por usuario.
3. `detalle_carrito (carrito_id, regalo_id)` UNIQUE: no duplicar el mismo regalo en el carrito.
4. `pedidos → usuarios` pasa de `ON DELETE CASCADE` a `RESTRICT`: borrar un usuario no debe borrar el historial de ventas.
5. `CHECK` de `precio >= 0`, `stock >= 0`, `cantidad > 0`.
6. Charset `utf8mb4` y motor InnoDB explícitos.

## 5. Lo que todavía falta (decisiones tuyas, con prioridad)
**Alta**
- ~~Ver pedidos~~ **Resuelto**: `mis_pedidos.php` (cliente) y `admin/pedidos.php` (admin, cambia el estado; al cancelar devuelve el stock y no permite reactivar).
- Editar producto: hoy solo hay alta y baja. Un producto que ya está en un pedido no se puede borrar (la FK lo impide, a propósito).
- Roles: la carpeta del sistema describe **tres** roles (cliente, vendedor/tienda, súper admin) y el DER tiene **dos** (`cliente`, `admin`). Hay que alinear uno con el otro. Saqué el selector "Quiero vender" del registro porque no tenía respaldo en la BD.

**Media**
- Lista de deseos y buscador: sacados de la barra superior porque no hacían nada. La carpeta del sistema los promete.
- Google/Facebook en login/registro: eran botones decorativos; los saqué. La documentación los promete.
- `index.php` conserva secciones de maqueta con contenido ficticio (opiniones, vendedores, formulario de newsletter que solo valida en el navegador). Presentalo como maqueta o sacalo.
- El checkout registra el pedido en estado `pendiente`; no hay pasarela de pago ni elección de envío.

**Baja**
- Sin límite de intentos de login; contraseña mínima de 6 caracteres (subirla a 8).
- Personalización del producto (nombre, fecha, vista previa en vivo): el diseño la tenía como elemento firma y no está conectada a la BD.

## 6. Qué se probó y qué no
Probado con PHP 8.3 (servidor integrado) + MariaDB 10.11: registro (incluido rol inyectado, email duplicado, contraseña corta, sin CSRF), login correcto e incorrecto, acceso a `/admin` como cliente (bloqueado), carrito con control de stock, confirmación de pedido (descuenta stock), alta de producto con imagen, rechazo de un archivo PHP disfrazado de `.png`, rechazo de precio negativo y categoría inválida, baja de producto con y sin pedidos, historial de pedidos del cliente, cambio de estado por el admin (cancelar devuelve stock, estado inválido rechazado).
**No probado:** Apache/XAMPP real (en particular el `.htaccess` de `uploads/`) ni navegadores. Hacé una pasada completa en tu XAMPP antes de presentar.

## 7. Checklist para la presentación
1. Importar el SQL en phpMyAdmin.
2. Registrar un usuario nuevo → iniciar sesión → agregar al carrito → confirmar pedido.
3. Entrar como admin → cargar un producto con imagen → verlo en el catálogo.
4. Tener a mano `si.vuerd` / `der.sql` para mostrar el DER y que coincida con phpMyAdmin.
