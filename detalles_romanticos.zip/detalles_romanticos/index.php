<?php
// index.php — portada + catálogo cargado desde la base de datos (tabla regalos)
$titulo = 'Detalles románticos personalizados';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

$regalos = $pdo->query('SELECT id, nombre, precio, stock, imagen, material, color, categoria
                        FROM regalos ORDER BY fecha_creacion DESC, id DESC')->fetchAll();
?>
<?php $__f = flash_mostrar(); if ($__f): ?><div class="container" style="padding-top:16px"><?= $__f ?></div><?php endif; ?>
<main>

  <!-- HERO -->
  <section class="hero">
    <div class="container">
      <div class="hero-copy">
        <span class="eyebrow">Marketplace romántico N°1 en LatAm</span>
        <h1>Detalles que dicen lo que <em>las palabras</em> no alcanzan a decir.</h1>
        <p>Flores, joyería grabada, chocolates y experiencias para sorprender a esa persona especial, con nombres, fechas y mensajes que cuentan su historia.</p>
        <div class="hero-cta">
          <a href="#catalogo" class="btn btn-primary">Explorar catálogo</a>
          <a href="#categorias" class="btn btn-outline">Ver categorías</a>
        </div>
        <div class="hero-trust">
          <div><strong>98%</strong><span>de pedidos entregados a tiempo</span></div>
          <div><strong>4.9/5</strong><span>calificación promedio</span></div>
        </div>
      </div>

      <!-- CARRUSEL DE PRODUCTOS (todos los de la tabla regalos, con o sin foto) -->
      <div class="hero-carousel" id="hero-carousel" role="region" aria-roledescription="carrusel" aria-label="Productos disponibles">
        <div class="hc-label"><span>Nuestros detalles</span><span class="hc-count"><?= count($regalos) ?> productos</span></div>
        <?php if ($regalos): ?>
        <div class="hc-viewport">
          <div class="hc-track">
            <?php foreach ($regalos as $n => $r): $cat = $r['categoria'] ?: 'otros'; ?>
            <a class="hc-slide" href="<?= e(url('producto.php?id=' . $r['id'])) ?>" aria-roledescription="diapositiva" aria-label="<?= ($n + 1) ?> de <?= count($regalos) ?>">
              <div class="hc-media">
                <?php if ($r['imagen']): ?>
                  <img src="<?= e(url('uploads/productos/' . $r['imagen'])) ?>" alt="<?= e($r['nombre']) ?>" loading="<?= $n === 0 ? 'eager' : 'lazy' ?>">
                <?php else: ?>
                  <span class="hc-emoji" aria-hidden="true"><?= EMOJI_CATEGORIA[$cat] ?? '💝' ?></span>
                <?php endif; ?>
                <?php if ((int)$r['stock'] === 0): ?><span class="tag tag-out">Sin stock</span><?php endif; ?>
              </div>
              <div class="hc-info">
                <strong class="hc-name"><?= e($r['nombre']) ?></strong>
                <span class="hc-price"><?= precio($r['precio']) ?></span>
              </div>
            </a>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="hc-controls">
          <button type="button" class="hc-btn" data-dir="-1" aria-label="Producto anterior">‹</button>
          <div class="hc-dots">
            <?php foreach ($regalos as $n => $r): ?>
            <button type="button" class="hc-dot<?= $n === 0 ? ' is-active' : '' ?>" data-go="<?= $n ?>" aria-label="Ir al producto <?= ($n + 1) ?>"></button>
            <?php endforeach; ?>
          </div>
          <button type="button" class="hc-btn" data-dir="1" aria-label="Producto siguiente">›</button>
        </div>
        <?php else: ?>
          <p class="empty-note">Todavía no hay productos cargados.</p>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- TRUST BAR -->
  <div class="trust-bar">
    <div class="container">
      <div class="trust-item">
        <span class="ic">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        </span>
        <div><strong>Personalización a medida</strong><span>Nombres, fechas y mensajes</span></div>
      </div>
      <div class="trust-item">
        <span class="ic">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13" rx="1"/><path d="M16 8h4l3 3v5h-7"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        </span>
        <div><strong>Envío express</strong><span>Entrega en 24 a 72 h</span></div>
      </div>
      <div class="trust-item">
        <span class="ic">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 3 6v6c0 5 4 8 9 10 5-2 9-5 9-10V6l-9-4Z"/></svg>
        </span>
        <div><strong>Garantía AMOR &amp; DETALLE</strong><span>Devolución y soporte de cambios</span></div>
      </div>
    </div>
  </div>

  <!-- CATEGORÍAS -->
  <section class="section" id="categorias">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Explorá por categoría</span>
        <h2>Un espacio pensado solo para el amor</h2>
        <p>Sin repuestos de auto ni electrodomésticos de por medio: cada filtro y cada campaña acá está pensada exclusivamente para tu historia.</p>
      </div>
      <div class="cat-grid">
        <a class="cat-card" href="#catalogo"><span class="ic">💐</span><strong>Flores</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">💍</span><strong>Joyería grabada</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">🍫</span><strong>Chocolates &amp; gourmet</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">🎁</span><strong>Cajas temáticas</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">✨</span><strong>Experiencias</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">📷</span><strong>Fotos &amp; álbumes</strong></a>
      </div>
    </div>
  </section>

  <!-- CÓMO FUNCIONA -->
  <section class="section section--blush" id="como-funciona">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Cómo funciona</span>
        <h2>De la idea al detalle, en cuatro pasos</h2>
      </div>
      <div class="steps">
        <div class="step">
          <div class="num">01</div>
          <h3>Elegí</h3>
          <p>Buscá por ocasión o categoría entre cientos de detalles únicos.</p>
        </div>
        <div class="step">
          <div class="num">02</div>
          <h3>Personalizá</h3>
          <p>Agregá nombres, fechas, fotos, mensajes, colores o estilo de empaque.</p>
        </div>
        <div class="step">
          <div class="num">03</div>
          <h3>Previsualizá</h3>
          <p>Mirá cómo queda tu detalle en tiempo real antes de confirmar la compra.</p>
        </div>
        <div class="step">
          <div class="num">04</div>
          <h3>Recibí con amor</h3>
          <p>Seguí el pedido en producción, envío y entrega — con soporte en todo momento.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- CATÁLOGO -->
  <section class="section" id="catalogo">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Catálogo destacado</span>
        <h2>Detalles con más historias de amor</h2>
      </div>

      <div class="filters">
        <button class="chip is-active" data-filter="todos">Todos</button>
        <button class="chip" data-filter="joyeria">Joyería</button>
        <button class="chip" data-filter="flores">Flores</button>
        <button class="chip" data-filter="gourmet">Gourmet</button>
        <button class="chip" data-filter="cajas">Cajas</button>
        <button class="chip" data-filter="experiencias">Experiencias</button>
      </div>

      <div class="product-grid">
        <?php if (!$regalos): ?>
          <p class="empty-note">Todavía no hay productos cargados.</p>
        <?php endif; ?>
        <?php foreach ($regalos as $r):
          $cat = $r['categoria'] ?: 'otros'; ?>
        <article class="product-card" data-category="<?= e($cat) ?>">
          <a class="product-media" href="<?= e(url('producto.php?id=' . $r['id'])) ?>" style="background:#F7DFE5;">
            <?php if ($r['imagen']): ?>
              <img src="<?= e(url('uploads/productos/' . $r['imagen'])) ?>" alt="<?= e($r['nombre']) ?>" class="product-img">
            <?php else: ?>
              <span><?= EMOJI_CATEGORIA[$cat] ?? '💝' ?></span>
            <?php endif; ?>
            <?php if ((int)$r['stock'] === 0): ?><span class="tag tag-out">Sin stock</span><?php endif; ?>
          </a>
          <div class="product-body">
            <span class="product-vendor"><?= e(CATEGORIAS[$cat] ?? 'Otros') ?></span>
            <h3><a href="<?= e(url('producto.php?id=' . $r['id'])) ?>"><?= e($r['nombre']) ?></a></h3>
            <span class="product-rating"><?= e($r['material']) ?> · <?= e($r['color']) ?></span>
            <div class="product-foot">
              <span class="price"><?= precio($r['precio']) ?></span>
              <?php if ((int)$r['stock'] > 0): ?>
              <form action="<?= e(url('carrito.php')) ?>" method="post">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="agregar">
                <input type="hidden" name="regalo_id" value="<?= (int)$r['id'] ?>">
                <button class="add-btn" type="submit" aria-label="Agregar al carrito">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                </button>
              </form>
              <?php endif; ?>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- PILARES -->
  <section class="section section--blush">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Por qué AMOR &amp; DETALLE</span>
        <h2>Cuatro pilares detrás de cada compra</h2>
      </div>
      <div class="pillars">
        <div class="pillar">
          <div class="ic">✎</div>
          <h3>Personalización profunda</h3>
          <p>No es una opción premium: es el estándar. Nombres, fechas, fotos y mensajes en cada producto.</p>
        </div>
        <div class="pillar">
          <div class="ic">♥</div>
          <h3>Especialización romántica</h3>
          <p>Cada categoría y campaña está pensada solo para el universo del amor.</p>
        </div>
        <div class="pillar">
          <div class="ic">✓</div>
          <h3>Confianza verificada</h3>
          <p>Productos revisados, reseñas con fotos y políticas claras de devolución.</p>
        </div>
        <div class="pillar">
          <div class="ic">✦</div>
          <h3>Experiencia emocional</h3>
          <p>Cada categoría y campaña estacional te acompaña, no es solo una transacción.</p>
        </div>
      </div>
      </div>
    </div>
  </section>

  <!-- TESTIMONIOS -->
  <section class="section section--blush" id="opiniones">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Historias reales</span>
        <h2>Detalles que se convirtieron en recuerdos</h2>
      </div>
      <div class="testi-grid">
        <div class="testi-card">
          <div class="testi-stars">★★★★★</div>
          <p>Personalicé un collar con la fecha de nuestro aniversario y pude ver el grabado antes de comprarlo. Llegó impecable.</p>
          <div class="testi-who">
            <span class="testi-avatar">MJ</span>
            <div><strong>Marisol J.</strong><span>Compradora verificada</span></div>
          </div>
        </div>
        <div class="testi-card">
          <div class="testi-stars">★★★★★</div>
          <p>Le regalé una caja con nuestras fotos y cartas. El seguimiento del pedido me tranquilizó todo el proceso.</p>
          <div class="testi-who">
            <span class="testi-avatar">RP</span>
            <div><strong>Rodrigo P.</strong><span>Comprador verificado</span></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CAMPAÑA / NEWSLETTER -->
  <section class="section">
    <div class="container">
      <div class="campaign">
        <span class="eyebrow">Próxima campaña</span>
        <h2>Enterate primero de San Valentín 2027</h2>
        <p>Sumate para recibir ofertas anticipadas, novedades del catálogo y guías de regalos por ocasión.</p>
        <form class="campaign-form" id="campaign-form">
          <input type="email" placeholder="tu@email.com" required>
          <button type="submit" class="btn btn-primary">Sumarme</button>
        </form>
        <p class="form-msg"></p>
      </div>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
