<?php
// index.php — portada + catálogo cargado desde la base de datos (tabla regalos)
$titulo = 'Detalles románticos personalizados';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

$regalos = $pdo->query('SELECT id, nombre, precio, stock, imagen, material, color, categoria
                        FROM regalos ORDER BY fecha_creacion DESC, id DESC')->fetchAll();
?>
<?php $__f = flash_mostrar(); if ($__f): ?><div class="container" style="padding-top:16px"><?= $__f ?></div><?php endif; ?>
<main>

  <!-- HERO -->
  <section class="hero">
    <div class="container">
      <div class="hero-copy">
        <span class="eyebrow">Marketplace romántico N°1 en LatAm</span>
        <h1>Detalles que dicen lo que <em>las palabras</em> no alcanzan a decir.</h1>
        <p>Personalizá flores, joyería grabada, chocolates y experiencias con nombres, fechas y mensajes — y mirá el resultado en tiempo real antes de comprar.</p>
        <div class="hero-cta">
          <a href="#catalogo" class="btn btn-primary">Explorar catálogo</a>
          <a href="#vendedores" class="btn btn-outline">Vender en AMOR &amp; DETALLE</a>
        </div>
        <div class="hero-trust">
          <div><strong>+1.200</strong><span>artesanos y tiendas verificadas</span></div>
          <div><strong>98%</strong><span>de pedidos entregados a tiempo</span></div>
          <div><strong>4.9/5</strong><span>calificación promedio</span></div>
        </div>
      </div>

      <div class="preview-card">
        <div class="preview-label">
          <span>Vista previa en vivo</span>
          <span class="dot" aria-hidden="true"></span>
        </div>

        <svg class="locket" viewBox="0 0 220 160" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stop-color="#E7D3A8"/>
              <stop offset="1" stop-color="#C39A4B"/>
            </linearGradient>
          </defs>
          <rect x="4" y="4" width="212" height="152" rx="18" fill="#FBF6F0" stroke="url(#goldGrad)" stroke-width="3"/>
          <path d="M110 46c-8-12-28-12-33 2-4 11 6 20 33 40 27-20 37-29 33-40-5-14-25-14-33-2Z" fill="#E2536B" opacity="0.9"/>
          <text id="engrave-name" x="110" y="112" text-anchor="middle" class="locket-engrave" font-size="17" fill="#6E1F3A">Tu nombre aquí</text>
          <text id="engrave-date" x="110" y="132" text-anchor="middle" font-size="11" letter-spacing="1" fill="#8a5b6e">00 · 00 · 0000</text>
        </svg>

        <div class="preview-fields">
          <div>
            <label for="preview-name">Grabado en la joya</label>
            <input type="text" id="preview-name" maxlength="24" placeholder="Ej: Sofía &amp; Mateo">
          </div>
          <div>
            <label for="preview-date">Fecha especial</label>
            <input type="text" id="preview-date" maxlength="14" placeholder="Ej: 14 · 02 · 2025">
          </div>
        </div>
        <p class="preview-hint">Así funciona en cada producto: elegís, personalizás y ves el resultado antes de pagar.</p>
      </div>
    </div>
  </section>

  <!-- TRUST BAR -->
  <div class="trust-bar">
    <div class="container">
      <div class="trust-item">
        <span class="ic">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6 9 17l-5-5"/></svg>
        </span>
        <div><strong>Vendedores verificados</strong><span>Identidad y calidad revisadas</span></div>
      </div>
      <div class="trust-item">
        <span class="ic">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        </span>
        <div><strong>Personalización en vivo</strong><span>Vista previa antes de comprar</span></div>
      </div>
      <div class="trust-item">
        <span class="ic">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13" rx="1"/><path d="M16 8h4l3 3v5h-7"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        </span>
        <div><strong>Envío express</strong><span>Entrega en 24 a 72 h</span></div>
      </div>
      <div class="trust-item">
        <span class="ic">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 3 6v6c0 5 4 8 9 10 5-2 9-5 9-10V6l-9-4Z"/></svg>
        </span>
        <div><strong>Garantía AMOR &amp; DETALLE</strong><span>Devolución y soporte de cambios</span></div>
      </div>
    </div>
  </div>

  <!-- CATEGORÍAS -->
  <section class="section" id="categorias">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Explorá por categoría</span>
        <h2>Un espacio pensado solo para el amor</h2>
        <p>Sin repuestos de auto ni electrodomésticos de por medio: cada filtro y cada campaña acá está pensada exclusivamente para tu historia.</p>
      </div>
      <div class="cat-grid">
        <a class="cat-card" href="#catalogo"><span class="ic">💐</span><strong>Flores</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">💍</span><strong>Joyería grabada</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">🍫</span><strong>Chocolates &amp; gourmet</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">🎁</span><strong>Cajas temáticas</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">✨</span><strong>Experiencias</strong></a>
        <a class="cat-card" href="#catalogo"><span class="ic">📷</span><strong>Fotos &amp; álbumes</strong></a>
      </div>
    </div>
  </section>

  <!-- CÓMO FUNCIONA -->
  <section class="section section--blush" id="como-funciona">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Cómo funciona</span>
        <h2>De la idea al detalle, en cuatro pasos</h2>
      </div>
      <div class="steps">
        <div class="step">
          <div class="num">01</div>
          <h3>Elegí</h3>
          <p>Buscá por ocasión, categoría o vendedor entre miles de detalles únicos.</p>
        </div>
        <div class="step">
          <div class="num">02</div>
          <h3>Personalizá</h3>
          <p>Agregá nombres, fechas, fotos, mensajes, colores o estilo de empaque.</p>
        </div>
        <div class="step">
          <div class="num">03</div>
          <h3>Previsualizá</h3>
          <p>Mirá cómo queda tu detalle en tiempo real antes de confirmar la compra.</p>
        </div>
        <div class="step">
          <div class="num">04</div>
          <h3>Recibí con amor</h3>
          <p>Seguí el pedido en producción, envío y entrega — con soporte en todo momento.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- CATÁLOGO -->
  <section class="section" id="catalogo">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Catálogo destacado</span>
        <h2>Detalles con más historias de amor</h2>
      </div>

      <div class="filters">
        <button class="chip is-active" data-filter="todos">Todos</button>
        <button class="chip" data-filter="joyeria">Joyería</button>
        <button class="chip" data-filter="flores">Flores</button>
        <button class="chip" data-filter="gourmet">Gourmet</button>
        <button class="chip" data-filter="cajas">Cajas</button>
        <button class="chip" data-filter="experiencias">Experiencias</button>
      </div>

      <div class="product-grid">
        <?php if (!$regalos): ?>
          <p class="empty-note">Todavía no hay productos cargados.</p>
        <?php endif; ?>
        <?php foreach ($regalos as $r):
          $cat = $r['categoria'] ?: 'otros'; ?>
        <article class="product-card" data-category="<?= e($cat) ?>">
          <a class="product-media" href="<?= e(url('producto.php?id=' . $r['id'])) ?>" style="background:#F7DFE5;">
            <?php if ($r['imagen']): ?>
              <img src="<?= e(url('uploads/productos/' . $r['imagen'])) ?>" alt="<?= e($r['nombre']) ?>" class="product-img">
            <?php else: ?>
              <span><?= EMOJI_CATEGORIA[$cat] ?? '💝' ?></span>
            <?php endif; ?>
            <?php if ((int)$r['stock'] === 0): ?><span class="tag tag-out">Sin stock</span><?php endif; ?>
          </a>
          <div class="product-body">
            <span class="product-vendor"><?= e(CATEGORIAS[$cat] ?? 'Otros') ?></span>
            <h3><a href="<?= e(url('producto.php?id=' . $r['id'])) ?>"><?= e($r['nombre']) ?></a></h3>
            <span class="product-rating"><?= e($r['material']) ?> · <?= e($r['color']) ?></span>
            <div class="product-foot">
              <span class="price"><?= precio($r['precio']) ?></span>
              <?php if ((int)$r['stock'] > 0): ?>
              <form action="<?= e(url('carrito.php')) ?>" method="post">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="agregar">
                <input type="hidden" name="regalo_id" value="<?= (int)$r['id'] ?>">
                <button class="add-btn" type="submit" aria-label="Agregar al carrito">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                </button>
              </form>
              <?php endif; ?>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- PILARES -->
  <section class="section section--blush">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Por qué AMOR &amp; DETALLE</span>
        <h2>Cinco pilares detrás de cada compra</h2>
      </div>
      <div class="pillars">
        <div class="pillar">
          <div class="ic">✎</div>
          <h3>Personalización profunda</h3>
          <p>No es una opción premium: es el estándar. Nombres, fechas, fotos y mensajes en cada producto.</p>
        </div>
        <div class="pillar">
          <div class="ic">♥</div>
          <h3>Especialización romántica</h3>
          <p>Cada categoría y campaña está pensada solo para el universo del amor.</p>
        </div>
        <div class="pillar">
          <div class="ic">✓</div>
          <h3>Confianza verificada</h3>
          <p>Vendedores verificados, reseñas con fotos y políticas claras de devolución.</p>
        </div>
        <div class="pillar">
          <div class="ic">✦</div>
          <h3>Experiencia emocional</h3>
          <p>Cada categoría y campaña estacional te acompaña, no es solo una transacción.</p>
        </div>
        <div class="pillar">
          <div class="ic">⚭</div>
          <h3>Ecosistema para creadores</h3>
          <p>Herramientas de gestión y visibilidad para artesanos y emprendedores.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- VENDEDORES -->
  <section class="section" id="vendedores">
    <div class="container">
      <div class="seller-banner">
        <div>
          <span class="eyebrow">Para artesanos y tiendas</span>
          <h2>Convertí tu talento en tu propia tienda dentro de AMOR &amp; DETALLE</h2>
          <p>Publicá productos, configurá tus propias opciones de personalización y llegá a compradores con intención real de regalar.</p>
          <div class="hero-cta" style="margin-top:24px;">
            <a href="<?= e(url('auth/registro.php')) ?>" class="btn btn-gold">Crear mi tienda</a>
            <a href="#" class="btn btn-ghost" style="border-color: rgba(251,246,240,0.35); color:#fff;">Conocer beneficios</a>
          </div>
        </div>
        <div class="seller-stats">
          <div><strong>+1.200</strong><span>tiendas activas</span></div>
          <div><strong>32%</strong><span>venta promedio en campañas</span></div>
          <div><strong>0$</strong><span>costo de desarrollo propio</span></div>
        </div>
      </div>
    </div>
  </section>

  <!-- TESTIMONIOS -->
  <section class="section section--blush" id="opiniones">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Historias reales</span>
        <h2>Detalles que se convirtieron en recuerdos</h2>
      </div>
      <div class="testi-grid">
        <div class="testi-card">
          <div class="testi-stars">★★★★★</div>
          <p>Personalicé un collar con la fecha de nuestro aniversario y pude ver el grabado antes de comprarlo. Llegó impecable.</p>
          <div class="testi-who">
            <span class="testi-avatar">MJ</span>
            <div><strong>Marisol J.</strong><span>Compradora verificada</span></div>
          </div>
        </div>
        <div class="testi-card">
          <div class="testi-stars">★★★★★</div>
          <p>Como florista, nunca había tenido tantos pedidos personalizados. La herramienta de personalización me ahorra horas.</p>
          <div class="testi-who">
            <span class="testi-avatar">DL</span>
            <div><strong>Daniel L.</strong><span>Vendedor — Florería Estación Sur</span></div>
          </div>
        </div>
        <div class="testi-card">
          <div class="testi-stars">★★★★★</div>
          <p>Le regalé una caja con nuestras fotos y cartas. El seguimiento del pedido me tranquilizó todo el proceso.</p>
          <div class="testi-who">
            <span class="testi-avatar">RP</span>
            <div><strong>Rodrigo P.</strong><span>Comprador verificado</span></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CAMPAÑA / NEWSLETTER -->
  <section class="section">
    <div class="container">
      <div class="campaign">
        <span class="eyebrow">Próxima campaña</span>
        <h2>Enterate primero de San Valentín 2027</h2>
        <p>Sumate para recibir ofertas anticipadas, nuevos vendedores destacados y guías de regalos por ocasión.</p>
        <form class="campaign-form" id="campaign-form">
          <input type="email" placeholder="tu@email.com" required>
          <button type="submit" class="btn btn-primary">Sumarme</button>
        </form>
        <p class="form-msg"></p>
      </div>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
