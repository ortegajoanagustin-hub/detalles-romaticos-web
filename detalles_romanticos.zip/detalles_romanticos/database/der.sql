-- =====================================================================
-- AMOR & DETALLE — DER (esquema) — exportado de si.vuerd
-- Solo estructura: para datos de prueba usar database/detalles_romanticos.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS detalles_romanticos
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE detalles_romanticos;

-- ---------- USUARIOS ----------
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,              -- hash de password_hash(), nunca texto plano
    rol ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- DIRECCION (direcciones de envío del usuario) ----------
CREATE TABLE direccion (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    descripcion VARCHAR(100) NOT NULL,               -- alias: "Casa", "Trabajo", "Casa de mamá"...
    calle VARCHAR(150) NOT NULL,
    ciudad VARCHAR(150) NOT NULL,
    codigo_postal VARCHAR(20) NOT NULL,
    es_principal BOOLEAN NOT NULL DEFAULT FALSE,     -- una sola principal por usuario (lo controla la app)
    INDEX idx_direccion_usuario (id_usuario),
    CONSTRAINT fk_direccion_usuario FOREIGN KEY (id_usuario)   -- CORREGIDO: antes apuntaba (id) en vez de (id_usuario)
        REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------- REGALOS (productos) ----------
CREATE TABLE regalos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(150) NOT NULL,
    descripcion VARCHAR(250) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    imagen VARCHAR(150) NULL,
    material VARCHAR(50) NOT NULL,
    color VARCHAR(50) NOT NULL,
    categoria VARCHAR(30) NOT NULL DEFAULT 'otros',   -- NUEVO: el catálogo filtra por categoría
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_regalos_precio CHECK (precio >= 0),
    CONSTRAINT chk_regalos_stock  CHECK (stock >= 0),
    INDEX idx_regalos_categoria (categoria)
) ENGINE=InnoDB;

-- ---------- CARRITO (uno por usuario) ----------
CREATE TABLE carrito (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL UNIQUE,                   -- NUEVO: UNIQUE => un solo carrito por usuario
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_carrito_usuario FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE detalle_carrito (
    id INT PRIMARY KEY AUTO_INCREMENT,
    carrito_id INT NOT NULL,
    regalo_id INT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    CONSTRAINT chk_detcar_cantidad CHECK (cantidad > 0),
    CONSTRAINT uq_carrito_regalo UNIQUE (carrito_id, regalo_id),   -- NUEVO: no duplicar el mismo regalo
    CONSTRAINT fk_detalle_carrito FOREIGN KEY (carrito_id)
        REFERENCES carrito(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_detalle_carrito_regalo FOREIGN KEY (regalo_id)
        REFERENCES regalos(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------- PEDIDOS ----------
CREATE TABLE pedidos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    estado ENUM('pendiente','pagado','enviado','recibido','cancelado') NOT NULL DEFAULT 'pendiente',
    fecha_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    direccion_id INT NULL,                           -- NUEVO: dirección elegida al comprar
    direccion_envio VARCHAR(500) NULL,               -- NUEVO: texto congelado al comprar (como precio_unitario)
    CONSTRAINT fk_pedido_usuario FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id) ON DELETE RESTRICT ON UPDATE CASCADE,  -- CAMBIO: no perder historial de ventas
    CONSTRAINT fk_pedido_direccion FOREIGN KEY (direccion_id)
        REFERENCES direccion(id) ON DELETE SET NULL ON UPDATE CASCADE  -- si borran la dirección, el pedido conserva el texto
) ENGINE=InnoDB;

CREATE TABLE detalle_pedido (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pedido_id INT NOT NULL,
    regalo_id INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,          -- precio congelado al momento de comprar
    CONSTRAINT chk_detped_cantidad CHECK (cantidad > 0),
    CONSTRAINT fk_detalle_pedido FOREIGN KEY (pedido_id)
        REFERENCES pedidos(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_detalle_regalo FOREIGN KEY (regalo_id)
        REFERENCES regalos(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;
