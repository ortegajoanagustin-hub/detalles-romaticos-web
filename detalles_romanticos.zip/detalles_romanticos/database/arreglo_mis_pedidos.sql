-- =====================================================================
-- AMOR & DETALLE — Arreglo de "Mis pedidos" (y del checkout)
-- Causa: el código usa pedidos.direccion_envio y pedidos.direccion_id,
-- pero esas columnas no existen en la base actual (falta la migración).
--
-- Uso: phpMyAdmin -> base detalles_romanticos -> pestaña SQL -> pegar -> Continuar
-- No borra usuarios, regalos, pedidos ni carritos.
-- =====================================================================
USE detalles_romanticos;

-- 1) Tabla direccion: la actual tiene la FK mal puesta (sobre `id` en vez de `id_usuario`).
--    Está vacía, así que se recrea sin perder datos.
DROP TABLE IF EXISTS direccion;
CREATE TABLE direccion (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    descripcion VARCHAR(100) NOT NULL,
    calle VARCHAR(150) NOT NULL,
    ciudad VARCHAR(150) NOT NULL,
    codigo_postal VARCHAR(20) NOT NULL,
    es_principal BOOLEAN NOT NULL DEFAULT FALSE,
    INDEX idx_direccion_usuario (id_usuario),
    CONSTRAINT fk_direccion_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2) Columnas nuevas en pedidos (los pedidos viejos quedan con NULL, y la página lo soporta).
ALTER TABLE pedidos
    ADD COLUMN IF NOT EXISTS direccion_id INT NULL,
    ADD COLUMN IF NOT EXISTS direccion_envio VARCHAR(500) NULL;

-- 3) Clave foránea del pedido hacia la dirección.
--    (Si te dice que fk_pedido_direccion ya existe, ignorá ese aviso.)
ALTER TABLE pedidos
    ADD CONSTRAINT fk_pedido_direccion FOREIGN KEY (direccion_id)
        REFERENCES direccion(id) ON DELETE SET NULL ON UPDATE CASCADE;
