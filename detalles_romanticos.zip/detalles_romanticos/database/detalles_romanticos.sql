-- =====================================================================
-- AMOR & DETALLE — Base de datos (versión de avance 16/10)
-- Basada en der.sql / si.vuerd. Reemplaza las tablas viejas de phpMyAdmin
-- (productos, detalle_pedidos, usuarios.mail) por el esquema del DER.
-- Uso:  mysql -u root < database/detalles_romanticos.sql
--       (o pegarlo en la pestaña SQL de phpMyAdmin)
-- =====================================================================

CREATE DATABASE IF NOT EXISTS detalles_romanticos
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE detalles_romanticos;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS detalle_pedidos;   -- tabla vieja
DROP TABLE IF EXISTS productos;         -- tabla vieja (se reemplaza por regalos)
DROP TABLE IF EXISTS detalle_pedido;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS direccion;
DROP TABLE IF EXISTS detalle_carrito;
DROP TABLE IF EXISTS carrito;
DROP TABLE IF EXISTS regalos;
DROP TABLE IF EXISTS usuarios;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- USUARIOS ----------
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,              -- hash de password_hash(), nunca texto plano
    rol ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- DIRECCION (direcciones de envío del usuario) ----------
CREATE TABLE direccion (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    descripcion VARCHAR(100) NOT NULL,               -- alias: "Casa", "Trabajo", "Casa de mamá"...
    calle VARCHAR(150) NOT NULL,
    ciudad VARCHAR(150) NOT NULL,
    codigo_postal VARCHAR(20) NOT NULL,
    es_principal BOOLEAN NOT NULL DEFAULT FALSE,     -- una sola principal por usuario (lo controla la app)
    INDEX idx_direccion_usuario (id_usuario),
    CONSTRAINT fk_direccion_usuario FOREIGN KEY (id_usuario)   -- CORREGIDO: antes apuntaba (id) en vez de (id_usuario)
        REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------- REGALOS (productos) ----------
CREATE TABLE regalos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(150) NOT NULL,
    descripcion VARCHAR(250) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    imagen VARCHAR(150) NULL,
    material VARCHAR(50) NOT NULL,
    color VARCHAR(50) NOT NULL,
    categoria VARCHAR(30) NOT NULL DEFAULT 'otros',   -- NUEVO: el catálogo filtra por categoría
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_regalos_precio CHECK (precio >= 0),
    CONSTRAINT chk_regalos_stock  CHECK (stock >= 0),
    INDEX idx_regalos_categoria (categoria)
) ENGINE=InnoDB;

-- ---------- CARRITO (uno por usuario) ----------
CREATE TABLE carrito (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL UNIQUE,                   -- NUEVO: UNIQUE => un solo carrito por usuario
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_carrito_usuario FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE detalle_carrito (
    id INT PRIMARY KEY AUTO_INCREMENT,
    carrito_id INT NOT NULL,
    regalo_id INT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    CONSTRAINT chk_detcar_cantidad CHECK (cantidad > 0),
    CONSTRAINT uq_carrito_regalo UNIQUE (carrito_id, regalo_id),   -- NUEVO: no duplicar el mismo regalo
    CONSTRAINT fk_detalle_carrito FOREIGN KEY (carrito_id)
        REFERENCES carrito(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_detalle_carrito_regalo FOREIGN KEY (regalo_id)
        REFERENCES regalos(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------- PEDIDOS ----------
CREATE TABLE pedidos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    estado ENUM('pendiente','pagado','enviado','recibido','cancelado') NOT NULL DEFAULT 'pendiente',
    fecha_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    direccion_id INT NULL,                           -- NUEVO: dirección elegida al comprar
    direccion_envio VARCHAR(500) NULL,               -- NUEVO: texto congelado al comprar (como precio_unitario)
    CONSTRAINT fk_pedido_usuario FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id) ON DELETE RESTRICT ON UPDATE CASCADE,  -- CAMBIO: no perder historial de ventas
    CONSTRAINT fk_pedido_direccion FOREIGN KEY (direccion_id)
        REFERENCES direccion(id) ON DELETE SET NULL ON UPDATE CASCADE  -- si borran la dirección, el pedido conserva el texto
) ENGINE=InnoDB;

CREATE TABLE detalle_pedido (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pedido_id INT NOT NULL,
    regalo_id INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,          -- precio congelado al momento de comprar
    CONSTRAINT chk_detped_cantidad CHECK (cantidad > 0),
    CONSTRAINT fk_detalle_pedido FOREIGN KEY (pedido_id)
        REFERENCES pedidos(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_detalle_regalo FOREIGN KEY (regalo_id)
        REFERENCES regalos(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- DATOS DE PRUEBA
-- admin@amordetalle.com / Admin1234     cliente@amordetalle.com / Cliente1234
-- (cambiar estas claves antes de publicar el sitio)
-- =====================================================================
INSERT INTO usuarios (nombre, email, password, rol) VALUES
 ('Administrador', 'admin@amordetalle.com',   '$2y$10$GY1j5ApkK8fDyFgScMXqcu/UPWe/HjwcQvOkzvfuF84YfQ4cZDQ2u', 'admin'),
 ('Cliente Demo',  'cliente@amordetalle.com', '$2y$10$fbMvGLTsIrUI1BK2O2YiVO5jPi2XPe/d.oq9U5kBVdi.ulPs42Ag2',   'cliente');
INSERT INTO carrito (usuario_id) VALUES (1), (2);
INSERT INTO direccion (id_usuario, descripcion, calle, ciudad, codigo_postal, es_principal) VALUES
 (2, 'Casa', 'Av. Siempreviva 742', 'Buenos Aires', '1000', TRUE);

INSERT INTO regalos (nombre, descripcion, precio, stock, imagen, material, color, categoria) VALUES
 ('Collar con grabado de coordenadas', 'Collar de plata con las coordenadas del lugar que ustedes elijan grabadas a mano.', 28500.00, 12, NULL, 'Plata 925', 'Plateado', 'joyeria'),
 ('Ramo de rosas con tarjeta dedicada', 'Docena de rosas frescas con tarjeta escrita con tu mensaje.', 14900.00, 20, NULL, 'Rosas naturales', 'Rojo', 'flores'),
 ('Caja de bombones con mensaje grabado', 'Bombones artesanales en caja con tu mensaje grabado en la tapa.', 9200.00, 30, NULL, 'Chocolate', 'Marrón', 'gourmet'),
 ('Caja sorpresa con fotos y cartas', 'Caja con fotos impresas, cartas y pequeños detalles para recordar momentos juntos.', 17300.00, 15, NULL, 'Cartón rígido', 'Rosa', 'cajas'),
 ('Cena romántica con carta personalizada', 'Cena para dos con menú y carta personalizados con su historia.', 32000.00, 8, NULL, 'Experiencia', 'No aplica', 'experiencias'),
 ('Pulsera doble con iniciales grabadas', 'Pulsera doble de acero con las iniciales de ambos.', 19800.00, 18, NULL, 'Acero quirúrgico', 'Dorado', 'joyeria'),
 ('Flor del mes, entrega mensual', 'Una flor de estación entregada cada mes con una nota breve.', 11400.00, 25, NULL, 'Flores de estación', 'Variado', 'flores'),
 ('Torta artesanal con foto comestible', 'Torta artesanal decorada con una foto comestible a elección.', 21700.00, 10, NULL, 'Masa y crema', 'Blanco', 'gourmet');
