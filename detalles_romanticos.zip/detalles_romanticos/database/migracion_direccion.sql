-- =====================================================================
-- AMOR & DETALLE — Migración: direcciones de envío
-- Para una base YA creada (no borra usuarios, regalos ni pedidos).
-- Uso: phpMyAdmin -> base detalles_romanticos -> pestaña SQL -> pegar -> Continuar
-- =====================================================================
USE detalles_romanticos;

-- La tabla que habías creado tenía FOREIGN KEY (id) REFERENCES usuarios(id):
-- eso ataba el id de la dirección al id del usuario (la dirección 5 solo podía
-- existir si existía el usuario 5) y dejaba id_usuario sin clave foránea.
-- Se recrea con la FK sobre id_usuario. Si ya cargaste direcciones, exportalas antes.
DROP TABLE IF EXISTS direccion;

CREATE TABLE direccion (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    descripcion VARCHAR(100) NOT NULL,
    calle VARCHAR(150) NOT NULL,
    ciudad VARCHAR(150) NOT NULL,
    codigo_postal VARCHAR(20) NOT NULL,
    es_principal BOOLEAN NOT NULL DEFAULT FALSE,
    INDEX idx_direccion_usuario (id_usuario),
    CONSTRAINT fk_direccion_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Cada pedido recuerda adónde se envió.
-- direccion_envio es una copia en texto: si el cliente edita o borra la dirección
-- después, el historial del pedido no cambia.
ALTER TABLE pedidos
    ADD COLUMN direccion_id INT NULL,
    ADD COLUMN direccion_envio VARCHAR(500) NULL,
    ADD CONSTRAINT fk_pedido_direccion FOREIGN KEY (direccion_id)
        REFERENCES direccion(id) ON DELETE SET NULL ON UPDATE CASCADE;
