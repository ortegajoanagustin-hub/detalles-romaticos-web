<?php // includes/footer.php — pie de página y script principal ?>
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a href="<?= e(url('index.php')) ?>" class="brand"><span class="mark">♥</span><span>AMOR &amp; DETALLE</span></a>
        <p>Donde cada detalle cuenta una historia de amor. Marketplace especializado en regalos románticos y personalizados en Latinoamérica.</p>
        <div class="footer-social">
          <a href="#" aria-label="Instagram">IG</a>
          <a href="#" aria-label="TikTok">TT</a>
          <a href="#" aria-label="Facebook">FB</a>
        </div>
      </div>
      <div class="footer-col">
        <h4>Comprar</h4>
        <ul>
          <li><a href="<?= e(url('index.php#categorias')) ?>">Categorías</a></li>
          <li><a href="<?= e(url('index.php#catalogo')) ?>">Catálogo</a></li>
          <li><a href="<?= e(url('index.php#como-funciona')) ?>">Cómo funciona</a></li>
          <li><a href="<?= e(url('index.php#opiniones')) ?>">Opiniones</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Ayuda</h4>
        <ul>
          <li><a href="#">Soporte</a></li>
          <li><a href="#">Devoluciones</a></li>
          <li><a href="#">Preguntas frecuentes</a></li>
          <li><a href="#">Términos y condiciones</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 AMOR &amp; DETALLE. Todos los derechos reservados.</span>
      <span>Carpeta del sistema v1.0 — Junio 2026</span>
    </div>
  </div>
</footer>

<script src="<?= e(url('js/main.js') . '?v=' . @filemtime(__DIR__ . '/../js/main.js')) ?>"></script>
</body>
</html>
