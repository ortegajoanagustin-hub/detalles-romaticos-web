<?php
// includes/header.php — <head> y apertura del <body>. Variables opcionales: $titulo, $body_clase
require_once __DIR__ . '/funciones.php';
$titulo = $titulo ?? 'AMOR & DETALLE';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($titulo) ?> — AMOR &amp; DETALLE</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= e(url('css/stylesheet.css') . '?v=' . @filemtime(__DIR__ . '/../css/stylesheet.css')) ?>">
</head>
<body class="<?= e($body_clase ?? '') ?>">
