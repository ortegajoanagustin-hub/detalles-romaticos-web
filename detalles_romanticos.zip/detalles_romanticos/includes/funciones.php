<?php
// includes/funciones.php — sesión, CSRF, mensajes flash y guardas de acceso.

session_start();

require_once __DIR__ . '/../config/conexion.php';

// URL base del proyecto (detecta la carpeta sola: /detalles_romanticos, /, etc.)
$__doc  = str_replace('\\', '/', rtrim((string)realpath($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\'));
$__raiz = str_replace('\\', '/', (string)realpath(__DIR__ . '/..'));
define('BASE_URL', ($__doc !== '' && strpos($__raiz, $__doc) === 0) ? substr($__raiz, strlen($__doc)) : '');

const CATEGORIAS = [
    'joyeria'      => 'Joyería',
    'flores'       => 'Flores',
    'gourmet'      => 'Gourmet',
    'cajas'        => 'Cajas',
    'experiencias' => 'Experiencias',
    'otros'        => 'Otros',
];
const EMOJI_CATEGORIA = [
    'joyeria' => '💍', 'flores' => '💐', 'gourmet' => '🍫',
    'cajas' => '🎁', 'experiencias' => '🍷', 'otros' => '💝',
];

function e($valor): string {                       // escapar salida HTML (anti-XSS)
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}
function largo(string $s): int {                   // longitud en caracteres (funciona aunque falte mbstring)
    return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : (int)preg_match_all('/./us', $s);
}
function url(string $ruta = ''): string {
    return BASE_URL . '/' . ltrim($ruta, '/');
}
function redirigir(string $ruta): void {
    header('Location: ' . url($ruta));
    exit;
}
function precio($n): string {                      // 28500 -> $28.500
    return '$' . number_format((float)$n, 0, ',', '.');
}

/* ---- CSRF ---- */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_campo(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}
function csrf_verificar(): void {
    $ok = isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
    if (!$ok) {
        http_response_code(403);
        die('Solicitud inválida (token CSRF). Volvé atrás y recargá la página.');
    }
}

/* ---- Mensajes flash (se muestran una sola vez) ---- */
function flash(string $tipo, string $texto): void {
    $_SESSION['flash'][] = ['tipo' => $tipo, 'texto' => $texto];
}
function flash_mostrar(): string {
    $html = '';
    foreach ($_SESSION['flash'] ?? [] as $m) {
        $clase = $m['tipo'] === 'ok' ? 'alert-ok' : 'alert-error';
        $html .= '<div class="alert ' . $clase . '">' . e($m['texto']) . '</div>';
    }
    unset($_SESSION['flash']);
    return $html;
}

/* ---- Autenticación y roles ---- */
function usuario_actual(): ?array {
    return $_SESSION['usuario'] ?? null;
}
function requerir_login(): void {
    if (!usuario_actual()) {
        flash('error', 'Iniciá sesión para continuar.');
        redirigir('auth/login.php');
    }
}
function requerir_admin(): void {
    requerir_login();
    if (usuario_actual()['rol'] !== 'admin') {
        http_response_code(403);
        flash('error', 'No tenés permiso para entrar a esa sección.');
        redirigir('index.php');
    }
}

/* ---- Carrito ---- */
function carrito_id(PDO $pdo, int $usuario_id): int {
    $st = $pdo->prepare('SELECT id FROM carrito WHERE usuario_id = ?');
    $st->execute([$usuario_id]);
    $id = $st->fetchColumn();
    if ($id) return (int)$id;
    $pdo->prepare('INSERT INTO carrito (usuario_id) VALUES (?)')->execute([$usuario_id]);
    return (int)$pdo->lastInsertId();
}
function carrito_cantidad(PDO $pdo): int {
    $u = usuario_actual();
    if (!$u) return 0;
    $st = $pdo->prepare('SELECT COALESCE(SUM(d.cantidad),0) FROM detalle_carrito d
                         JOIN carrito c ON c.id = d.carrito_id WHERE c.usuario_id = ?');
    $st->execute([$u['id']]);
    return (int)$st->fetchColumn();
}

/* ---- Direcciones de envío ---- */
function direcciones_usuario(PDO $pdo, int $usuario_id): array {   // la principal primero
    $st = $pdo->prepare('SELECT id, descripcion, calle, ciudad, codigo_postal, es_principal
                         FROM direccion WHERE id_usuario = ? ORDER BY es_principal DESC, id');
    $st->execute([$usuario_id]);
    return $st->fetchAll();
}
function direccion_texto(array $d): string {       // "Casa — Av. Siempreviva 742, Buenos Aires (CP 1000)"
    return $d['descripcion'] . ' — ' . $d['calle'] . ', ' . $d['ciudad'] . ' (CP ' . $d['codigo_postal'] . ')';
}
