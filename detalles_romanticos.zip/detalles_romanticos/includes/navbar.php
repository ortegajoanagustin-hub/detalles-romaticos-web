<?php
// includes/navbar.php — barra superior (cambia según haya sesión y según el rol)
$u = usuario_actual();
$cant = carrito_cantidad($pdo);
?>
<header class="site-header">
  <div class="header-bar">
    <a href="<?= e(url('index.php')) ?>" class="brand">
      <span class="mark">♥</span>
      <span>AMOR &amp; DETALLE<small>Detalles con historia</small></span>
    </a>

    <nav class="main-nav" aria-label="Navegación principal">
      <a href="<?= e(url('index.php#categorias')) ?>">Categorías</a>
      <a href="<?= e(url('index.php#como-funciona')) ?>">Cómo funciona</a>
      <a href="<?= e(url('index.php#catalogo')) ?>">Catálogo</a>
      <?php if ($u && $u['rol'] === 'admin'): ?>
        <a href="<?= e(url('admin/dashboard.php')) ?>">Panel admin</a>
        <a href="<?= e(url('admin/pedidos.php')) ?>">Pedidos</a>
      <?php elseif ($u): ?>
        <a href="<?= e(url('mis_pedidos.php')) ?>">Mis pedidos</a>
        <a href="<?= e(url('mis_direcciones.php')) ?>">Mis direcciones</a>
      <?php endif; ?>
    </nav>

    <div class="header-actions">
      <a class="icon-btn" href="<?= e(url('carrito.php')) ?>" aria-label="Carrito">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
        <?php if ($cant > 0): ?><span class="badge" style="display:grid"><?= $cant ?></span><?php endif; ?>
      </a>
      <?php if ($u): ?>
        <span class="user-chip">Hola, <?= e(explode(' ', $u['nombre'])[0]) ?></span>
        <a class="btn btn-ghost" href="<?= e(url('auth/log_out.php')) ?>" style="padding:9px 18px;">Salir</a>
      <?php else: ?>
        <a class="btn btn-ghost" href="<?= e(url('auth/login.php')) ?>" style="padding:9px 18px;">Ingresar</a>
        <a class="btn btn-primary" href="<?= e(url('auth/registro.php')) ?>" style="padding:9px 18px;">Crear cuenta</a>
      <?php endif; ?>
      <button class="nav-toggle" aria-label="Abrir menú" aria-expanded="false"><span></span></button>
    </div>
  </div>
</header>
