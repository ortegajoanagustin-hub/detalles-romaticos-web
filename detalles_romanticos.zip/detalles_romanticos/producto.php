<?php
// producto.php?id=N — detalle de un regalo
require_once __DIR__ . '/includes/funciones.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$st = $pdo->prepare('SELECT * FROM regalos WHERE id = ?');
$st->execute([$id ?: 0]);
$r = $st->fetch();
if (!$r) { http_response_code(404); flash('error', 'Ese producto no existe.'); redirigir('index.php'); }

$titulo = $r['nombre'];
$cat = $r['categoria'] ?: 'otros';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/navbar.php';
?>
<main class="page">
  <div class="container">
    <?= flash_mostrar() ?>
    <a href="<?= e(url('index.php#catalogo')) ?>" class="back-link">← Volver al catálogo</a>
    <div class="detail">
      <div class="detail-media" style="background:#F7DFE5;">
        <?php if ($r['imagen']): ?>
          <img src="<?= e(url('uploads/productos/' . $r['imagen'])) ?>" alt="<?= e($r['nombre']) ?>">
        <?php else: ?>
          <span class="detail-emoji"><?= EMOJI_CATEGORIA[$cat] ?? '💝' ?></span>
        <?php endif; ?>
      </div>
      <div class="detail-info">
        <span class="product-vendor"><?= e(CATEGORIAS[$cat] ?? 'Otros') ?></span>
        <h1><?= e($r['nombre']) ?></h1>
        <p class="price price-lg"><?= precio($r['precio']) ?></p>
        <p><?= e($r['descripcion']) ?></p>
        <ul class="specs">
          <li><strong>Material:</strong> <?= e($r['material']) ?></li>
          <li><strong>Color:</strong> <?= e($r['color']) ?></li>
          <li><strong>Stock:</strong> <?= (int)$r['stock'] > 0 ? (int)$r['stock'] . ' disponibles' : 'Sin stock' ?></li>
        </ul>
        <?php if ((int)$r['stock'] > 0): ?>
        <form action="<?= e(url('carrito.php')) ?>" method="post" class="detail-form">
          <?= csrf_campo() ?>
          <input type="hidden" name="accion" value="agregar">
          <input type="hidden" name="regalo_id" value="<?= (int)$r['id'] ?>">
          <label for="cantidad">Cantidad</label>
          <input type="number" id="cantidad" name="cantidad" value="1" min="1" max="<?= (int)$r['stock'] ?>" class="qty">
          <button type="submit" class="btn btn-primary">Agregar al carrito</button>
        </form>
        <?php else: ?>
          <p class="alert alert-error">Este producto está agotado por ahora.</p>
        <?php endif; ?>
      </div>
    </div>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
