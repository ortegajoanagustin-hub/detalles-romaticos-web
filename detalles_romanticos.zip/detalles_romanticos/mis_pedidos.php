<?php
// mis_pedidos.php — historial de pedidos del cliente logueado
require_once __DIR__ . '/includes/funciones.php';
requerir_login();
$uid = usuario_actual()['id'];

$st = $pdo->prepare('SELECT id, total, estado, fecha_pedido, direccion_envio FROM pedidos WHERE usuario_id = ? ORDER BY id DESC');
$st->execute([$uid]);
$pedidos = $st->fetchAll();

$det = $pdo->prepare('SELECT r.nombre, d.cantidad, d.precio_unitario
                      FROM detalle_pedido d JOIN regalos r ON r.id = d.regalo_id WHERE d.pedido_id = ?');

$titulo = 'Mis pedidos';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/navbar.php';
?>
<main class="page">
  <div class="container">
    <h1 class="page-title">Mis pedidos</h1>
    <?= flash_mostrar() ?>
    <?php if (!$pedidos): ?>
      <p class="empty-note">Todavía no hiciste ningún pedido. <a href="<?= e(url('index.php#catalogo')) ?>">Ver el catálogo</a></p>
    <?php endif; ?>
    <?php foreach ($pedidos as $p): $det->execute([$p['id']]); ?>
      <section class="order-card">
        <div class="order-head">
          <strong>Pedido #<?= (int)$p['id'] ?></strong>
          <span class="estado estado-<?= e($p['estado']) ?>"><?= e(ucfirst($p['estado'])) ?></span>
          <span><?= e(date('d/m/Y H:i', strtotime($p['fecha_pedido']))) ?></span>
          <span class="price"><?= precio($p['total']) ?></span>
        </div>
        <?php if ($p['direccion_envio']): ?><p class="order-ship">Envío a: <?= e($p['direccion_envio']) ?></p><?php endif; ?>
        <ul class="order-items">
          <?php foreach ($det->fetchAll() as $d): ?>
            <li><?= (int)$d['cantidad'] ?> × <?= e($d['nombre']) ?> — <?= precio($d['precio_unitario']) ?> c/u</li>
          <?php endforeach; ?>
        </ul>
      </section>
    <?php endforeach; ?>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
