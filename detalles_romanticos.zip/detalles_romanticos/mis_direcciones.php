<?php
// mis_direcciones.php — el cliente ve, agrega, edita, elimina y marca como principal sus direcciones de envío
require_once __DIR__ . '/includes/funciones.php';
requerir_login();
$uid = (int)usuario_actual()['id'];

/* Quita la marca de principal a todas y se la pone a $id (siempre dentro de una transacción) */
function marcar_principal(PDO $pdo, int $uid, int $id): void {
    $pdo->prepare('UPDATE direccion SET es_principal = FALSE WHERE id_usuario = ?')->execute([$uid]);
    $pdo->prepare('UPDATE direccion SET es_principal = TRUE WHERE id = ? AND id_usuario = ?')->execute([$id, $uid]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $accion = $_POST['accion'] ?? '';
    $id     = (int)($_POST['id'] ?? 0);

    try {
        if ($accion === 'guardar') {
            $desc   = trim($_POST['descripcion'] ?? '');
            $calle  = trim($_POST['calle'] ?? '');
            $ciudad = trim($_POST['ciudad'] ?? '');
            $cp     = trim($_POST['codigo_postal'] ?? '');
            $princ  = isset($_POST['es_principal']);

            $errores = [];
            if (largo($desc) < 2 || largo($desc) > 100)    $errores[] = 'La descripción debe tener entre 2 y 100 caracteres.';
            if (largo($calle) < 3 || largo($calle) > 150)  $errores[] = 'Ingresá la calle y el número (máx. 150 caracteres).';
            if (largo($ciudad) < 2 || largo($ciudad) > 150) $errores[] = 'Ingresá la ciudad (máx. 150 caracteres).';
            if ($cp === '' || largo($cp) > 20)             $errores[] = 'Ingresá el código postal (máx. 20 caracteres).';

            if ($errores) {
                foreach ($errores as $m) flash('error', $m);
                $_SESSION['old'] = ['id' => $id, 'descripcion' => $desc, 'calle' => $calle, 'ciudad' => $ciudad,
                                    'codigo_postal' => $cp, 'es_principal' => $princ];
                redirigir('mis_direcciones.php' . ($id ? '?editar=' . $id : ''));
            }

            $pdo->beginTransaction();
            if ($id) {   // editar: solo si la dirección es de este usuario
                $st = $pdo->prepare('UPDATE direccion SET descripcion=?, calle=?, ciudad=?, codigo_postal=? WHERE id=? AND id_usuario=?');
                $st->execute([$desc, $calle, $ciudad, $cp, $id, $uid]);
                $existe = $pdo->prepare('SELECT COUNT(*) FROM direccion WHERE id=? AND id_usuario=?');
                $existe->execute([$id, $uid]);
                if (!$existe->fetchColumn()) throw new RuntimeException('Esa dirección no existe.');
            } else {     // alta: la primera dirección del usuario queda como principal sola
                $tiene = $pdo->prepare('SELECT COUNT(*) FROM direccion WHERE id_usuario = ?');
                $tiene->execute([$uid]);
                $es_primera = ((int)$tiene->fetchColumn() === 0);
                $pdo->prepare('INSERT INTO direccion (id_usuario, descripcion, calle, ciudad, codigo_postal) VALUES (?,?,?,?,?)')
                    ->execute([$uid, $desc, $calle, $ciudad, $cp]);
                $id = (int)$pdo->lastInsertId();
                if ($es_primera) $princ = true;
            }
            if ($princ) marcar_principal($pdo, $uid, $id);
            $pdo->commit();
            flash('ok', 'Dirección guardada.');

        } elseif ($accion === 'principal') {
            $pdo->beginTransaction();
            marcar_principal($pdo, $uid, $id);
            $pdo->commit();
            flash('ok', 'Dirección principal actualizada.');

        } elseif ($accion === 'eliminar') {
            $pdo->beginTransaction();
            $st = $pdo->prepare('SELECT es_principal FROM direccion WHERE id = ? AND id_usuario = ? FOR UPDATE');
            $st->execute([$id, $uid]);
            $era_principal = $st->fetchColumn();
            if ($era_principal === false) throw new RuntimeException('Esa dirección no existe.');
            $pdo->prepare('DELETE FROM direccion WHERE id = ? AND id_usuario = ?')->execute([$id, $uid]);
            if ($era_principal) {   // si borró la principal, la más antigua que quede pasa a serlo
                $sig = $pdo->prepare('SELECT id FROM direccion WHERE id_usuario = ? ORDER BY id LIMIT 1');
                $sig->execute([$uid]);
                if ($nuevo = $sig->fetchColumn()) marcar_principal($pdo, $uid, (int)$nuevo);
            }
            $pdo->commit();
            flash('ok', 'Dirección eliminada.');
        }
    } catch (RuntimeException $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', $ex->getMessage());
    } catch (PDOException $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('Direcciones: ' . $ex->getMessage());
        flash('error', 'No pudimos guardar los cambios. Probá de nuevo.');
    }
    redirigir('mis_direcciones.php');
}

$direcciones = direcciones_usuario($pdo, $uid);

/* Formulario: vacío (alta), con los datos de la dirección (?editar=ID) o con lo que escribió si hubo errores */
$form = ['id' => 0, 'descripcion' => '', 'calle' => '', 'ciudad' => '', 'codigo_postal' => '', 'es_principal' => false];
if (isset($_GET['editar'])) {
    foreach ($direcciones as $d) if ((int)$d['id'] === (int)$_GET['editar']) { $form = $d; break; }
}
if (!empty($_SESSION['old'])) { $form = array_merge($form, $_SESSION['old']); unset($_SESSION['old']); }

$titulo = 'Mis direcciones';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/navbar.php';
?>
<main class="page">
  <div class="container">
    <h1 class="page-title">Mis direcciones</h1>
    <?= flash_mostrar() ?>

    <div class="addr-layout">
      <section>
        <?php if (!$direcciones): ?>
          <p class="empty-note">Todavía no cargaste ninguna dirección. Agregá una para poder confirmar pedidos.</p>
        <?php endif; ?>
        <?php foreach ($direcciones as $d): ?>
          <article class="order-card addr-card">
            <div class="order-head">
              <strong><?= e($d['descripcion']) ?></strong>
              <?php if ($d['es_principal']): ?><span class="estado estado-pagado">Principal</span><?php endif; ?>
            </div>
            <p class="addr-line"><?= e($d['calle']) ?><br><?= e($d['ciudad']) ?> — CP <?= e($d['codigo_postal']) ?></p>
            <div class="addr-actions">
              <a class="btn btn-ghost btn-sm" href="<?= e(url('mis_direcciones.php?editar=' . (int)$d['id'])) ?>">Editar</a>
              <?php if (!$d['es_principal']): ?>
                <form method="post" class="inline-form">
                  <?= csrf_campo() ?>
                  <input type="hidden" name="accion" value="principal">
                  <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
                  <button class="btn btn-ghost btn-sm" type="submit">Hacer principal</button>
                </form>
              <?php endif; ?>
              <form method="post" class="inline-form" onsubmit="return confirm('¿Eliminar esta dirección?');">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="eliminar">
                <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
                <button class="btn btn-ghost btn-sm" type="submit">Eliminar</button>
              </form>
            </div>
          </article>
        <?php endforeach; ?>
      </section>

      <form method="post" class="panel-form" action="mis_direcciones.php" novalidate>
        <h2 class="addr-form-title"><?= $form['id'] ? 'Editar dirección' : 'Nueva dirección' ?></h2>
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="guardar">
        <input type="hidden" name="id" value="<?= (int)$form['id'] ?>">
        <div class="field">
          <label for="dir-desc">Descripción (ej: Casa, Trabajo)</label>
          <input type="text" id="dir-desc" name="descripcion" maxlength="100" value="<?= e($form['descripcion']) ?>" required>
        </div>
        <div class="field">
          <label for="dir-calle">Calle y número</label>
          <input type="text" id="dir-calle" name="calle" maxlength="150" value="<?= e($form['calle']) ?>" required>
        </div>
        <div class="form-grid">
          <div class="field">
            <label for="dir-ciudad">Ciudad</label>
            <input type="text" id="dir-ciudad" name="ciudad" maxlength="150" value="<?= e($form['ciudad']) ?>" required>
          </div>
          <div class="field">
            <label for="dir-cp">Código postal</label>
            <input type="text" id="dir-cp" name="codigo_postal" maxlength="20" value="<?= e($form['codigo_postal']) ?>" required>
          </div>
        </div>
        <div class="checkbox-row">
          <input type="checkbox" id="dir-princ" name="es_principal" value="1" <?= $form['es_principal'] ? 'checked' : '' ?>>
          <label for="dir-princ">Usar como dirección principal</label>
        </div>
        <button type="submit" class="btn btn-primary"><?= $form['id'] ? 'Guardar cambios' : 'Agregar dirección' ?></button>
        <?php if ($form['id']): ?>
          <a class="btn btn-ghost" href="<?= e(url('mis_direcciones.php')) ?>">Cancelar</a>
        <?php endif; ?>
      </form>
    </div>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
