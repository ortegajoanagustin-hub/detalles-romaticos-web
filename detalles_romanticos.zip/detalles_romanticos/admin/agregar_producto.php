<?php
// admin/agregar_producto.php — formulario para cargar un regalo nuevo
require_once __DIR__ . '/../includes/funciones.php';
requerir_admin();
$old = $_SESSION['old'] ?? []; unset($_SESSION['old']);

$titulo = 'Agregar producto';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>
<main class="page">
  <div class="container container-narrow">
    <a href="dashboard.php" class="back-link">← Volver al panel</a>
    <h1 class="page-title">Agregar producto</h1>
    <?= flash_mostrar() ?>

    <form action="guardar_producto.php" method="post" enctype="multipart/form-data" class="panel-form">
      <?= csrf_campo() ?>
      <div class="field">
        <label for="nombre">Nombre</label>
        <input type="text" id="nombre" name="nombre" maxlength="150" value="<?= e($old['nombre'] ?? '') ?>" required>
      </div>
      <div class="field">
        <label for="descripcion">Descripción (máx. 250 caracteres)</label>
        <textarea id="descripcion" name="descripcion" maxlength="250" rows="3" required><?= e($old['descripcion'] ?? '') ?></textarea>
      </div>
      <div class="form-grid">
        <div class="field">
          <label for="precio">Precio (ARS)</label>
          <input type="number" id="precio" name="precio" min="0" step="0.01" value="<?= e($old['precio'] ?? '') ?>" required>
        </div>
        <div class="field">
          <label for="stock">Stock</label>
          <input type="number" id="stock" name="stock" min="0" step="1" value="<?= e($old['stock'] ?? '0') ?>" required>
        </div>
      </div>
      <div class="form-grid">
        <div class="field">
          <label for="material">Material</label>
          <input type="text" id="material" name="material" maxlength="50" value="<?= e($old['material'] ?? '') ?>" required>
        </div>
        <div class="field">
          <label for="color">Color</label>
          <input type="text" id="color" name="color" maxlength="50" value="<?= e($old['color'] ?? '') ?>" required>
        </div>
      </div>
      <div class="field">
        <label for="categoria">Categoría</label>
        <select id="categoria" name="categoria" required>
          <?php foreach (CATEGORIAS as $k => $v): ?>
            <option value="<?= e($k) ?>" <?= (($old['categoria'] ?? '') === $k) ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="imagen">Imagen (JPG, PNG o WEBP, hasta 2 MB — opcional)</label>
        <input type="file" id="imagen" name="imagen" accept="image/jpeg,image/png,image/webp">
      </div>
      <button type="submit" class="btn btn-primary">Guardar producto</button>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
