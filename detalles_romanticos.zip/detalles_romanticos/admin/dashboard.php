<?php
// admin/dashboard.php — panel del administrador: resumen + listado de productos
require_once __DIR__ . '/../includes/funciones.php';
requerir_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'eliminar') {
    csrf_verificar();
    $id = (int)($_POST['id'] ?? 0);
    try {
        $st = $pdo->prepare('SELECT imagen FROM regalos WHERE id = ?');
        $st->execute([$id]);
        $img = $st->fetchColumn();
        $pdo->prepare('DELETE FROM regalos WHERE id = ?')->execute([$id]);
        if ($img && preg_match('/^[a-f0-9]{32}\.(jpg|png|webp)$/', $img)) @unlink(__DIR__ . '/../uploads/productos/' . $img);
        flash('ok', 'Producto eliminado.');
    } catch (PDOException $ex) {
        // La FK ON DELETE RESTRICT impide borrar regalos que ya están en pedidos/carritos
        flash('error', 'No se puede eliminar: el producto ya figura en carritos o pedidos.');
    }
    redirigir('admin/dashboard.php');
}

$stats = [
    'Productos' => (int)$pdo->query('SELECT COUNT(*) FROM regalos')->fetchColumn(),
    'Clientes'  => (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol='cliente'")->fetchColumn(),
    'Pedidos'   => (int)$pdo->query('SELECT COUNT(*) FROM pedidos')->fetchColumn(),
];
$regalos = $pdo->query('SELECT id, nombre, precio, stock, categoria, imagen, fecha_creacion FROM regalos ORDER BY id DESC')->fetchAll();

$titulo = 'Panel de administración';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>
<main class="page">
  <div class="container">
    <div class="page-head">
      <h1 class="page-title">Panel de administración</h1>
      <span><a class="btn btn-ghost" href="pedidos.php">Ver pedidos</a>
      <a class="btn btn-primary" href="agregar_producto.php">+ Agregar producto</a></span>
    </div>
    <?= flash_mostrar() ?>

    <div class="stat-row">
      <?php foreach ($stats as $k => $v): ?>
        <div class="stat"><span class="stat-n"><?= $v ?></span><span><?= e($k) ?></span></div>
      <?php endforeach; ?>
    </div>

    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>#</th><th>Nombre</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Imagen</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($regalos as $r): ?>
          <tr>
            <td><?= (int)$r['id'] ?></td>
            <td><a href="<?= e(url('producto.php?id=' . $r['id'])) ?>"><?= e($r['nombre']) ?></a></td>
            <td><?= e(CATEGORIAS[$r['categoria']] ?? $r['categoria']) ?></td>
            <td><?= precio($r['precio']) ?></td>
            <td><?= (int)$r['stock'] ?></td>
            <td><?= $r['imagen'] ? 'Sí' : '—' ?></td>
            <td>
              <form method="post" class="inline-form" onsubmit="return confirm('¿Eliminar este producto?');">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="eliminar">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="btn btn-ghost btn-sm" type="submit">Eliminar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
