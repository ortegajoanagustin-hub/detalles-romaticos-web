<?php
// admin/editar_producto.php — editar un producto existente (solo admin).
// Muestra el formulario cargado con los datos actuales y, al enviarlo (POST), valida y hace UPDATE.
require_once __DIR__ . '/../includes/funciones.php';
requerir_admin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$st = $pdo->prepare('SELECT * FROM regalos WHERE id = ?');
$st->execute([$id]);
$producto = $st->fetch();
if (!$producto) {
    flash('error', 'El producto que querés editar no existe.');
    redirigir('admin/dashboard.php');
}

$v = $producto;          // valores que se muestran en el formulario
$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();

    $v['nombre']      = trim($_POST['nombre'] ?? '');
    $v['descripcion'] = trim($_POST['descripcion'] ?? '');
    $v['precio']      = $_POST['precio'] ?? '';
    $v['stock']       = $_POST['stock'] ?? '';
    $v['material']    = trim($_POST['material'] ?? '');
    $v['color']       = trim($_POST['color'] ?? '');
    $v['categoria']   = $_POST['categoria'] ?? '';

    if ($v['nombre'] === '' || largo($v['nombre']) > 150)           $errores[] = 'El nombre es obligatorio (máx. 150 caracteres).';
    if ($v['descripcion'] === '' || largo($v['descripcion']) > 250) $errores[] = 'La descripción es obligatoria (máx. 250 caracteres).';
    if (!is_numeric($v['precio']) || $v['precio'] < 0 || $v['precio'] > 99999999.99) $errores[] = 'El precio debe ser un número válido, mayor o igual a 0.';
    if (filter_var($v['stock'], FILTER_VALIDATE_INT) === false || (int)$v['stock'] < 0) $errores[] = 'El stock debe ser un entero mayor o igual a 0.';
    if ($v['material'] === '' || largo($v['material']) > 50)        $errores[] = 'El material es obligatorio (máx. 50 caracteres).';
    if ($v['color'] === '' || largo($v['color']) > 50)              $errores[] = 'El color es obligatorio (máx. 50 caracteres).';
    if (!array_key_exists($v['categoria'], CATEGORIAS))             $errores[] = 'Elegí una categoría válida.';

    // Imagen nueva (opcional): se valida el tipo REAL del archivo
    $nueva_imagen = null;
    $f = $_FILES['imagen'] ?? null;
    if ($f && $f['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($f['error'] !== UPLOAD_ERR_OK) {
            $errores[] = 'No se pudo subir la imagen (código ' . (int)$f['error'] . ').';
        } elseif ($f['size'] > 2 * 1024 * 1024) {
            $errores[] = 'La imagen supera los 2 MB.';
        } else {
            $permitidos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
            if (!isset($permitidos[$mime]) || @getimagesize($f['tmp_name']) === false) {
                $errores[] = 'La imagen debe ser JPG, PNG o WEBP.';
            } else {
                $nueva_imagen = bin2hex(random_bytes(16)) . '.' . $permitidos[$mime];
            }
        }
    }

    if (!$errores) {
        $imagen_final = $producto['imagen'];
        $dir = __DIR__ . '/../uploads/productos/';

        if ($nueva_imagen) {
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            if (move_uploaded_file($f['tmp_name'], $dir . $nueva_imagen)) {
                $imagen_final = $nueva_imagen;
            } else {
                $errores[] = 'No se pudo guardar la imagen en el servidor (¿permisos de uploads/?).';
            }
        } elseif (!empty($_POST['quitar_imagen'])) {
            $imagen_final = null;
        }
    }

    if (!$errores) {
        $pdo->prepare('UPDATE regalos SET nombre=?, descripcion=?, precio=?, stock=?, imagen=?, material=?, color=?, categoria=? WHERE id=?')
            ->execute([$v['nombre'], $v['descripcion'], $v['precio'], (int)$v['stock'], $imagen_final,
                       $v['material'], $v['color'], $v['categoria'], $id]);

        // Borrar del disco la imagen anterior si fue reemplazada o quitada
        $vieja = $producto['imagen'];
        if ($vieja && $vieja !== $imagen_final && preg_match('/^[a-f0-9]{32}\.(jpg|png|webp)$/', $vieja)) {
            @unlink($dir . $vieja);
        }

        flash('ok', 'Producto "' . $v['nombre'] . '" actualizado correctamente.');
        redirigir('admin/dashboard.php');
    }
    foreach ($errores as $err) flash('error', $err);
}

$titulo = 'Editar producto';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>
<main class="page">
  <div class="container container-narrow">
    <a href="dashboard.php" class="back-link">← Volver al panel</a>
    <h1 class="page-title">Editar producto #<?= (int)$id ?></h1>
    <?= flash_mostrar() ?>

    <form action="editar_producto.php?id=<?= (int)$id ?>" method="post" enctype="multipart/form-data" class="panel-form">
      <?= csrf_campo() ?>
      <input type="hidden" name="id" value="<?= (int)$id ?>">
      <div class="field">
        <label for="nombre">Nombre</label>
        <input type="text" id="nombre" name="nombre" maxlength="150" value="<?= e($v['nombre']) ?>" required>
      </div>
      <div class="field">
        <label for="descripcion">Descripción (máx. 250 caracteres)</label>
        <textarea id="descripcion" name="descripcion" maxlength="250" rows="3" required><?= e($v['descripcion']) ?></textarea>
      </div>
      <div class="form-grid">
        <div class="field">
          <label for="precio">Precio (ARS)</label>
          <input type="number" id="precio" name="precio" min="0" step="0.01" value="<?= e($v['precio']) ?>" required>
        </div>
        <div class="field">
          <label for="stock">Stock</label>
          <input type="number" id="stock" name="stock" min="0" step="1" value="<?= e($v['stock']) ?>" required>
        </div>
      </div>
      <div class="form-grid">
        <div class="field">
          <label for="material">Material</label>
          <input type="text" id="material" name="material" maxlength="50" value="<?= e($v['material']) ?>" required>
        </div>
        <div class="field">
          <label for="color">Color</label>
          <input type="text" id="color" name="color" maxlength="50" value="<?= e($v['color']) ?>" required>
        </div>
      </div>
      <div class="field">
        <label for="categoria">Categoría</label>
        <select id="categoria" name="categoria" required>
          <?php foreach (CATEGORIAS as $k => $nom): ?>
            <option value="<?= e($k) ?>" <?= ($v['categoria'] === $k) ? 'selected' : '' ?>><?= e($nom) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="imagen">Imagen (JPG, PNG o WEBP, hasta 2 MB)</label>
        <?php if ($producto['imagen']): ?>
          <img class="edit-thumb" src="<?= e(url('uploads/productos/' . $producto['imagen'])) ?>" alt="Imagen actual">
          <label class="check-line"><input type="checkbox" name="quitar_imagen" value="1"> Quitar la imagen actual</label>
          <small>Si subís una nueva, reemplaza a la actual.</small>
        <?php else: ?>
          <small>Este producto todavía no tiene imagen.</small>
        <?php endif; ?>
        <input type="file" id="imagen" name="imagen" accept="image/jpeg,image/png,image/webp">
      </div>
      <button type="submit" class="btn btn-primary">Guardar cambios</button>
      <a href="dashboard.php" class="btn btn-ghost">Cancelar</a>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
