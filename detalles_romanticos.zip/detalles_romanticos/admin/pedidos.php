<?php
// admin/pedidos.php — todos los pedidos y cambio de estado
require_once __DIR__ . '/../includes/funciones.php';
requerir_admin();

const ESTADOS = ['pendiente', 'pagado', 'enviado', 'recibido', 'cancelado'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $id    = (int)($_POST['id'] ?? 0);
    $nuevo = $_POST['estado'] ?? '';
    if (!in_array($nuevo, ESTADOS, true)) {
        flash('error', 'Estado inválido.');
        redirigir('admin/pedidos.php');
    }
    try {
        $pdo->beginTransaction();
        $st = $pdo->prepare('SELECT estado FROM pedidos WHERE id = ? FOR UPDATE');
        $st->execute([$id]);
        $actual = $st->fetchColumn();
        if ($actual === false) throw new RuntimeException('El pedido no existe.');
        if ($actual === 'cancelado' && $nuevo !== 'cancelado') throw new RuntimeException('Un pedido cancelado no se puede reactivar (el stock ya fue devuelto).');
        if ($actual !== 'cancelado' && $nuevo === 'cancelado') {   // devolver stock
            $pdo->prepare('UPDATE regalos r JOIN detalle_pedido d ON d.regalo_id = r.id
                           SET r.stock = r.stock + d.cantidad WHERE d.pedido_id = ?')->execute([$id]);
        }
        $pdo->prepare('UPDATE pedidos SET estado = ? WHERE id = ?')->execute([$nuevo, $id]);
        $pdo->commit();
        flash('ok', "Pedido #$id actualizado a «$nuevo».");
    } catch (RuntimeException $ex) {
        $pdo->rollBack();
        flash('error', $ex->getMessage());
    }
    redirigir('admin/pedidos.php');
}

$pedidos = $pdo->query('SELECT p.id, p.total, p.estado, p.fecha_pedido, p.direccion_envio, u.nombre, u.email
                        FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id ORDER BY p.id DESC')->fetchAll();
$det = $pdo->prepare('SELECT r.nombre, d.cantidad FROM detalle_pedido d JOIN regalos r ON r.id = d.regalo_id WHERE d.pedido_id = ?');

$titulo = 'Pedidos';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>
<main class="page">
  <div class="container">
    <div class="page-head">
      <h1 class="page-title">Pedidos</h1>
      <a class="btn btn-ghost" href="dashboard.php">← Panel</a>
    </div>
    <?= flash_mostrar() ?>
    <?php if (!$pedidos): ?><p class="empty-note">Todavía no hay pedidos.</p><?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>#</th><th>Cliente</th><th>Productos</th><th>Envío</th><th>Total</th><th>Fecha</th><th>Estado</th></tr></thead>
        <tbody>
        <?php foreach ($pedidos as $p): $det->execute([$p['id']]); ?>
          <tr>
            <td><?= (int)$p['id'] ?></td>
            <td><?= e($p['nombre']) ?><br><small><?= e($p['email']) ?></small></td>
            <td><?php foreach ($det->fetchAll() as $d): ?><?= (int)$d['cantidad'] ?> × <?= e($d['nombre']) ?><br><?php endforeach; ?></td>
            <td><?= $p['direccion_envio'] ? e($p['direccion_envio']) : '—' ?></td>
            <td><?= precio($p['total']) ?></td>
            <td><?= e(date('d/m/Y H:i', strtotime($p['fecha_pedido']))) ?></td>
            <td>
              <form method="post" class="inline-form">
                <?= csrf_campo() ?>
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <select name="estado" class="qty" style="width:auto">
                  <?php foreach (ESTADOS as $s): ?>
                    <option value="<?= $s ?>" <?= $p['estado'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                  <?php endforeach; ?>
                </select>
                <button class="btn btn-ghost btn-sm" type="submit">Guardar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
