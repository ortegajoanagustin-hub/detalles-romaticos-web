<?php
// admin/guardar_producto.php — valida y guarda el producto (INSERT con consulta preparada)
require_once __DIR__ . '/../includes/funciones.php';
requerir_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirigir('admin/agregar_producto.php');
csrf_verificar();

$nombre      = trim($_POST['nombre'] ?? '');
$descripcion = trim($_POST['descripcion'] ?? '');
$precio      = $_POST['precio'] ?? '';
$stock       = $_POST['stock'] ?? '';
$material    = trim($_POST['material'] ?? '');
$color       = trim($_POST['color'] ?? '');
$categoria   = $_POST['categoria'] ?? '';

$errores = [];
if ($nombre === '' || largo($nombre) > 150)           $errores[] = 'El nombre es obligatorio (máx. 150 caracteres).';
if ($descripcion === '' || largo($descripcion) > 250) $errores[] = 'La descripción es obligatoria (máx. 250 caracteres).';
if (!is_numeric($precio) || $precio < 0 || $precio > 99999999.99) $errores[] = 'El precio debe ser un número válido, mayor o igual a 0.';
if (filter_var($stock, FILTER_VALIDATE_INT) === false || (int)$stock < 0) $errores[] = 'El stock debe ser un entero mayor o igual a 0.';
if ($material === '' || largo($material) > 50)        $errores[] = 'El material es obligatorio (máx. 50 caracteres).';
if ($color === '' || largo($color) > 50)              $errores[] = 'El color es obligatorio (máx. 50 caracteres).';
if (!array_key_exists($categoria, CATEGORIAS))            $errores[] = 'Elegí una categoría válida.';

// Imagen (opcional): se valida el tipo REAL del archivo, no solo la extensión
$nombre_imagen = null;
$f = $_FILES['imagen'] ?? null;
if ($f && $f['error'] !== UPLOAD_ERR_NO_FILE) {
    if ($f['error'] !== UPLOAD_ERR_OK) {
        $errores[] = 'No se pudo subir la imagen (código ' . (int)$f['error'] . ').';
    } elseif ($f['size'] > 2 * 1024 * 1024) {
        $errores[] = 'La imagen supera los 2 MB.';
    } else {
        $permitidos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        if (!isset($permitidos[$mime]) || @getimagesize($f['tmp_name']) === false) {
            $errores[] = 'La imagen debe ser JPG, PNG o WEBP.';
        } else {
            $nombre_imagen = bin2hex(random_bytes(16)) . '.' . $permitidos[$mime];
        }
    }
}

if ($errores) {
    foreach ($errores as $err) flash('error', $err);
    $_SESSION['old'] = compact('nombre', 'descripcion', 'precio', 'stock', 'material', 'color', 'categoria');
    redirigir('admin/agregar_producto.php');
}

if ($nombre_imagen) {
    $dir = __DIR__ . '/../uploads/productos/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    if (!move_uploaded_file($f['tmp_name'], $dir . $nombre_imagen)) {
        flash('error', 'No se pudo guardar la imagen en el servidor (¿permisos de uploads/?).');
        $_SESSION['old'] = compact('nombre', 'descripcion', 'precio', 'stock', 'material', 'color', 'categoria');
        redirigir('admin/agregar_producto.php');
    }
}

$pdo->prepare('INSERT INTO regalos (nombre, descripcion, precio, stock, imagen, material, color, categoria)
               VALUES (?,?,?,?,?,?,?,?)')
    ->execute([$nombre, $descripcion, $precio, (int)$stock, $nombre_imagen, $material, $color, $categoria]);

flash('ok', 'Producto "' . $nombre . '" guardado correctamente.');
redirigir('admin/dashboard.php');
