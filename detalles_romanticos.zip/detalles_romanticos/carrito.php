<?php
// carrito.php — ver carrito, agregar, cambiar cantidad, quitar y confirmar compra
require_once __DIR__ . '/includes/funciones.php';
requerir_login();
$uid = usuario_actual()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $accion    = $_POST['accion'] ?? '';
    $regalo_id = (int)($_POST['regalo_id'] ?? 0);
    $cantidad  = max(1, (int)($_POST['cantidad'] ?? 1));
    $cid       = carrito_id($pdo, $uid);
    $volver    = 'carrito.php';

    if ($accion === 'agregar') {
        $st = $pdo->prepare('SELECT stock FROM regalos WHERE id = ?');
        $st->execute([$regalo_id]);
        $stock = $st->fetchColumn();
        if ($stock === false) {
            flash('error', 'Ese producto no existe.');
        } else {
            $st = $pdo->prepare('SELECT cantidad FROM detalle_carrito WHERE carrito_id = ? AND regalo_id = ?');
            $st->execute([$cid, $regalo_id]);
            $nueva = (int)$st->fetchColumn() + $cantidad;
            if ($nueva > (int)$stock) {
                flash('error', 'No hay stock suficiente (disponible: ' . (int)$stock . ').');
            } else {
                $pdo->prepare('INSERT INTO detalle_carrito (carrito_id, regalo_id, cantidad) VALUES (?,?,?)
                               ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)')
                    ->execute([$cid, $regalo_id, $nueva]);
                flash('ok', 'Agregado al carrito.');
            }
        }
        // Vuelve a la página de origen solo si pertenece a este mismo sitio
        $ref   = $_SERVER['HTTP_REFERER'] ?? '';
        $mismo = $ref !== '' && parse_url($ref, PHP_URL_HOST) === parse_url('http://' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST);
        header('Location: ' . ($mismo ? $ref : url('index.php'))); exit;

    } elseif ($accion === 'actualizar') {
        $st = $pdo->prepare('SELECT stock FROM regalos WHERE id = ?');
        $st->execute([$regalo_id]);
        $stock = (int)$st->fetchColumn();
        if ($cantidad > $stock) { flash('error', 'Solo hay ' . $stock . ' en stock.'); }
        else $pdo->prepare('UPDATE detalle_carrito SET cantidad = ? WHERE carrito_id = ? AND regalo_id = ?')->execute([$cantidad, $cid, $regalo_id]);

    } elseif ($accion === 'quitar') {
        $pdo->prepare('DELETE FROM detalle_carrito WHERE carrito_id = ? AND regalo_id = ?')->execute([$cid, $regalo_id]);

    } elseif ($accion === 'comprar') {
        try {
            $pdo->beginTransaction();
            $did = (int)($_POST['direccion_id'] ?? 0);
            $st = $pdo->prepare('SELECT descripcion, calle, ciudad, codigo_postal FROM direccion WHERE id = ? AND id_usuario = ?');
            $st->execute([$did, $uid]);
            $dir = $st->fetch();
            if (!$dir) throw new RuntimeException('Elegí una dirección de envío para confirmar el pedido.');
            $st = $pdo->prepare('SELECT d.regalo_id, d.cantidad, r.precio, r.stock, r.nombre
                                 FROM detalle_carrito d JOIN regalos r ON r.id = d.regalo_id
                                 WHERE d.carrito_id = ? FOR UPDATE');
            $st->execute([$cid]);
            $items = $st->fetchAll();
            if (!$items) throw new RuntimeException('Tu carrito está vacío.');
            $total = 0;
            foreach ($items as $it) {
                if ($it['cantidad'] > $it['stock']) throw new RuntimeException('Sin stock suficiente de "' . $it['nombre'] . '".');
                $total += $it['cantidad'] * $it['precio'];
            }
            $pdo->prepare('INSERT INTO pedidos (usuario_id, total, direccion_id, direccion_envio) VALUES (?, ?, ?, ?)')
                ->execute([$uid, $total, $did, direccion_texto($dir)]);
            $pid = (int)$pdo->lastInsertId();
            $ins = $pdo->prepare('INSERT INTO detalle_pedido (pedido_id, regalo_id, cantidad, precio_unitario) VALUES (?,?,?,?)');
            $upd = $pdo->prepare('UPDATE regalos SET stock = stock - ? WHERE id = ?');
            foreach ($items as $it) {
                $ins->execute([$pid, $it['regalo_id'], $it['cantidad'], $it['precio']]);
                $upd->execute([$it['cantidad'], $it['regalo_id']]);
            }
            $pdo->prepare('DELETE FROM detalle_carrito WHERE carrito_id = ?')->execute([$cid]);
            $pdo->commit();
            flash('ok', '¡Pedido #' . $pid . ' registrado! Total: ' . precio($total) . ' (estado: pendiente).');
        } catch (RuntimeException $ex) {
            $pdo->rollBack();
            flash('error', $ex->getMessage());
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('Compra: ' . $ex->getMessage());
            flash('error', 'No pudimos registrar el pedido. Probá de nuevo.');
        }
    }
    redirigir($volver);
}

$st = $pdo->prepare('SELECT r.id, r.nombre, r.precio, r.stock, r.categoria, d.cantidad
                     FROM detalle_carrito d
                     JOIN carrito c ON c.id = d.carrito_id
                     JOIN regalos r ON r.id = d.regalo_id
                     WHERE c.usuario_id = ? ORDER BY d.id');
$st->execute([$uid]);
$items = $st->fetchAll();
$total = array_sum(array_map(fn($i) => $i['cantidad'] * $i['precio'], $items));
$direcciones = direcciones_usuario($pdo, $uid);   // la principal viene primero y queda marcada

$titulo = 'Tu carrito';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/navbar.php';
?>
<main class="page">
  <div class="container">
    <h1 class="page-title">Tu carrito</h1>
    <?= flash_mostrar() ?>
    <?php if (!$items): ?>
      <p class="empty-note">Tu carrito está vacío. <a href="<?= e(url('index.php#catalogo')) ?>">Ver el catálogo</a></p>
    <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>Producto</th><th>Precio</th><th>Cantidad</th><th>Subtotal</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($items as $i): ?>
          <tr>
            <td><a href="<?= e(url('producto.php?id=' . $i['id'])) ?>"><?= e($i['nombre']) ?></a></td>
            <td><?= precio($i['precio']) ?></td>
            <td>
              <form action="carrito.php" method="post" class="inline-form">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="actualizar">
                <input type="hidden" name="regalo_id" value="<?= (int)$i['id'] ?>">
                <input type="number" name="cantidad" value="<?= (int)$i['cantidad'] ?>" min="1" max="<?= (int)$i['stock'] ?>" class="qty">
                <button class="btn btn-ghost btn-sm" type="submit">Actualizar</button>
              </form>
            </td>
            <td><?= precio($i['cantidad'] * $i['precio']) ?></td>
            <td>
              <form action="carrito.php" method="post" class="inline-form">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="quitar">
                <input type="hidden" name="regalo_id" value="<?= (int)$i['id'] ?>">
                <button class="btn btn-ghost btn-sm" type="submit">Quitar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="cart-total">
      <span>Total: <strong class="price price-lg"><?= precio($total) ?></strong></span>
      <form action="carrito.php" method="post">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="comprar">
        <?php if (!$direcciones): ?>
          <p class="empty-note">Necesitás una dirección de envío para confirmar. <a href="<?= e(url('mis_direcciones.php')) ?>">Agregar dirección</a></p>
        <?php else: ?>
          <div class="addr-pick">
            <strong>Enviar a:</strong>
            <?php foreach ($direcciones as $n => $d): ?>
              <label>
                <input type="radio" name="direccion_id" value="<?= (int)$d['id'] ?>" <?= $n === 0 ? 'checked' : '' ?>>
                <span><?= e(direccion_texto($d)) ?><?= $d['es_principal'] ? ' · principal' : '' ?></span>
              </label>
            <?php endforeach; ?>
            <a href="<?= e(url('mis_direcciones.php')) ?>">Administrar direcciones</a>
          </div>
          <button class="btn btn-primary" type="submit" style="margin-top:14px">Confirmar pedido</button>
        <?php endif; ?>
      </form>
    </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
