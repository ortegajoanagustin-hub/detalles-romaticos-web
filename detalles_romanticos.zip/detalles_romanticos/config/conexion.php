<?php
// config/conexion.php — conexión PDO a MySQL/MariaDB (XAMPP: usuario root, sin contraseña)

$host    = 'localhost';
$db      = 'detalles_romanticos';
$user    = 'root';
$pass    = '';
$charset = 'utf8mb4';

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    // En producción no se muestra el detalle del error: se registra en el log.
    error_log('Error de conexión: ' . $e->getMessage());
    die('No se pudo conectar con la base de datos. Verificá que MySQL esté iniciado y que la base "' . htmlspecialchars($db) . '" exista.');
}
