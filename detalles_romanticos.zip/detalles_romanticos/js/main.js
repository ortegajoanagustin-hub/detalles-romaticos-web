/* ==========================================================================
   AMOR & DETALLE — app.js
   Interacciones del front: menú móvil, filtros de catálogo y validación de
   formularios de login/registro (la validación definitiva la hace PHP).
   El carrito y la sesión viven en el servidor (PHP + MySQL).
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initNavToggle();
  initHeroCarousel();
  initFavorites();
  initFilters();
  initCampaignForm();
  initLoginForm();
  initRegistroForm();
  initPasswordToggles();
});

/* ---------- Menú móvil ---------- */
function initNavToggle(){
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if(!toggle || !nav) return;
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    nav.style.display = open ? 'flex' : '';
    toggle.setAttribute('aria-expanded', String(open));
  });
}

/* ---------- Carrusel de productos (hero) ---------- */
function initHeroCarousel(){
  const root = document.getElementById('hero-carousel');
  if(!root) return;
  const track = root.querySelector('.hc-track');
  const slides = root.querySelectorAll('.hc-slide');
  const dots = root.querySelectorAll('.hc-dot');
  if(!track || slides.length < 2){
    root.querySelectorAll('.hc-controls').forEach(c => c.style.display = 'none');
    return;
  }

  let index = 0, timer = null;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function go(i){
    index = (i + slides.length) % slides.length;
    track.style.transform = `translateX(-${index * 100}%)`;
    dots.forEach((d, n) => d.classList.toggle('is-active', n === index));
  }
  function start(){
    if(reduceMotion) return;
    stop();
    timer = setInterval(() => go(index + 1), 4500);
  }
  function stop(){ clearInterval(timer); timer = null; }

  root.querySelectorAll('.hc-btn').forEach(b => b.addEventListener('click', () => { go(index + Number(b.dataset.dir)); start(); }));
  dots.forEach(d => d.addEventListener('click', () => { go(Number(d.dataset.go)); start(); }));

  root.addEventListener('mouseenter', stop);
  root.addEventListener('mouseleave', start);

  // deslizar con el dedo en celulares
  let x0 = null;
  track.addEventListener('touchstart', e => { x0 = e.touches[0].clientX; stop(); }, {passive:true});
  track.addEventListener('touchend', e => {
    if(x0 !== null){
      const dx = e.changedTouches[0].clientX - x0;
      if(Math.abs(dx) > 40) go(index + (dx < 0 ? 1 : -1));
    }
    x0 = null; start();
  });

  go(0);
  start();
}

/* ---------- Favoritos (lista de deseos) ---------- */
function initFavorites(){
  const favButtons = document.querySelectorAll('.fav');
  const wishBadge = document.getElementById('wish-count');
  let saved = new Set(JSON.parse(localStorage.getItem('ad_wishlist') || '[]'));

  syncButtons();
  updateBadge();

  favButtons.forEach(btn => {
    const id = btn.dataset.productId;
    btn.addEventListener('click', () => {
      if(saved.has(id)){
        saved.delete(id);
        btn.classList.remove('is-active');
      } else {
        saved.add(id);
        btn.classList.add('is-active');
        showToast('Guardado en tu lista de deseos');
      }
      localStorage.setItem('ad_wishlist', JSON.stringify([...saved]));
      updateBadge();
    });
  });

  function syncButtons(){
    favButtons.forEach(btn => {
      if(saved.has(btn.dataset.productId)) btn.classList.add('is-active');
    });
  }
  function updateBadge(){
    if(wishBadge){
      wishBadge.textContent = saved.size;
      wishBadge.style.display = saved.size > 0 ? 'grid' : 'none';
    }
  }
}

/* ---------- Filtro de categorías en el catálogo ---------- */
function initFilters(){
  const chips = document.querySelectorAll('.chip[data-filter]');
  const cards = document.querySelectorAll('.product-card[data-category]');
  if(!chips.length || !cards.length) return;

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('is-active'));
      chip.classList.add('is-active');
      const filter = chip.dataset.filter;
      cards.forEach(card => {
        const match = filter === 'todos' || card.dataset.category === filter;
        card.style.display = match ? '' : 'none';
      });
    });
  });
}

/* ---------- Newsletter / campaña ---------- */
function initCampaignForm(){
  const form = document.getElementById('campaign-form');
  if(!form) return;
  const msg = form.querySelector('.form-msg');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = form.querySelector('input[type="email"]').value.trim();
    if(!isValidEmail(email)){
      msg.textContent = 'Ingresá un email válido para sumarte.';
      msg.className = 'form-msg err';
      return;
    }
    msg.textContent = '¡Listo! Te avisamos antes que nadie sobre San Valentín 2027.';
    msg.className = 'form-msg ok';
    form.reset();
  });
}

/* ---------- Toast genérico ---------- */
let toastTimer = null;
function showToast(text){
  let toast = document.querySelector('.toast');
  if(!toast){
    toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span class="dot">♥</span><span class="toast-text"></span>`;
    document.body.appendChild(toast);
  }
  toast.querySelector('.toast-text').textContent = text;
  toast.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 2600);
}

/* ---------- Validación reutilizable ---------- */
function isValidEmail(value){
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}
function setFieldError(input, message){
  const wrap = input.closest('.field');
  if(!wrap) return;
  const errorEl = wrap.querySelector('.error-msg');
  if(message){
    input.classList.add('is-error');
    if(errorEl) errorEl.textContent = message;
  } else {
    input.classList.remove('is-error');
    if(errorEl) errorEl.textContent = '';
  }
}

/* ---------- Mostrar / ocultar contraseña ---------- */
function initPasswordToggles(){
  document.querySelectorAll('.toggle-pass').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.closest('.input-wrap').querySelector('input');
      const isPass = input.type === 'password';
      input.type = isPass ? 'text' : 'password';
      btn.textContent = isPass ? 'Ocultar' : 'Ver';
    });
  });
}

/* ---------- Login ---------- */
function initLoginForm(){
  const form = document.getElementById('login-form');
  if(!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = form.querySelector('#login-email');
    const pass = form.querySelector('#login-password');
    let valid = true;

    if(!isValidEmail(email.value.trim())){
      setFieldError(email, 'Ingresá un email válido.');
      valid = false;
    } else setFieldError(email, '');

    if(pass.value.length < 6){
      setFieldError(pass, 'La contraseña debe tener al menos 6 caracteres.');
      valid = false;
    } else setFieldError(pass, '');

    if(!valid) return;

    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Ingresando...';
    form.submit();   // la validación real la hace auth/procesar_login.php
  });
}

/* ---------- Registro ---------- */
function initRegistroForm(){
  const form = document.getElementById('registro-form');
  if(!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = form.querySelector('#registro-name');
    const email = form.querySelector('#registro-email');
    const pass = form.querySelector('#registro-password');
    const confirm = form.querySelector('#registro-confirm');
    const terms = form.querySelector('#registro-terms');
    let valid = true;

    if(name.value.trim().length < 2){
      setFieldError(name, 'Contanos tu nombre completo.');
      valid = false;
    } else setFieldError(name, '');

    if(!isValidEmail(email.value.trim())){
      setFieldError(email, 'Ingresá un email válido.');
      valid = false;
    } else setFieldError(email, '');

    if(pass.value.length < 6){
      setFieldError(pass, 'Mínimo 6 caracteres.');
      valid = false;
    } else setFieldError(pass, '');

    if(confirm.value !== pass.value || !confirm.value){
      setFieldError(confirm, 'Las contraseñas no coinciden.');
      valid = false;
    } else setFieldError(confirm, '');

    if(terms && !terms.checked){
      showToast('Aceptá los términos para continuar');
      valid = false;
    }

    if(!valid) return;

    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Creando cuenta...';
    form.submit();   // la validación real la hace auth/procesar_registro.php
  });
}
